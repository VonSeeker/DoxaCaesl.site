const CACHE_NAME = 'doxacare-clinic-cache-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  'https://cdn.tailwindcss.com',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[Service Worker] Caching App Shell and CDNs');
      return cache.addAll(ASSETS_TO_CACHE);
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('[Service Worker] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  // We only cache GET requests
  if (event.request.method !== 'GET') return;

  const requestUrl = new URL(event.request.url);

  // Skip dev environment specific HMR endpoints (like @vite, @react-refresh, node_modules)
  if (
    requestUrl.pathname.startsWith('/@') || 
    requestUrl.pathname.startsWith('/src/') ||
    requestUrl.pathname.endsWith('.ts') ||
    requestUrl.pathname.endsWith('.tsx') ||
    requestUrl.pathname.includes('node_modules')
  ) {
    return;
  }

  const isCdn = event.request.url.includes('tailwindcss.com') ||
                event.request.url.includes('cloudflare.com') ||
                event.request.url.includes('unpkg.com') ||
                event.request.url.includes('cdnjs.cloudflare.com');

  if (isCdn) {
    // Cache-First, fallback to Network
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) return cachedResponse;
        return fetch(event.request).then((networkResponse) => {
          if (!networkResponse || (networkResponse.status !== 200 && networkResponse.status !== 0)) {
            return networkResponse;
          }
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
          return networkResponse;
        }).catch(() => {
          // Offline and not in cache
          return new Response('Offline asset unavailable', { status: 503, statusText: 'Offline' });
        });
      })
    );
  } else {
    // Stale-While-Revalidate for app page/scripts
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        const fetchPromise = fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
          return networkResponse;
        }).catch(() => {
          // ignore network failures silently on background refresh
        });

        return cachedResponse || fetchPromise;
      })
    );
  }
});
