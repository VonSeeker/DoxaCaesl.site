
import React from 'react';
import { Language } from '../types';
import BrandIcon from './BrandIcon';
import { auth } from '../firebase';

interface HeaderProps {
  view: string;
  onBack: () => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  currentUser?: any;
  onSignOut?: () => void;
  onNavigateToView?: (view: any) => void;
}

const Header: React.FC<HeaderProps> = ({ 
  view, 
  onBack, 
  language, 
  setLanguage,
  currentUser,
  onSignOut,
  onNavigateToView
}) => {
  const isKrio = language === Language.KRIO;

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm px-4 py-3 flex items-center justify-between no-print">
      <div className="flex items-center space-x-2">
        {view !== 'home' && (
          <button 
            onClick={onBack}
            className="w-10 h-10 -ml-2 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-100 active:scale-90 transition-all cursor-pointer"
          >
            <i className="fas fa-arrow-left"></i>
          </button>
        )}
        <div className="flex items-center" onClick={() => onNavigateToView?.('home')} className="cursor-pointer">
          <BrandIcon className="w-10 h-10 text-green-600 mr-2" />
          <div className="flex flex-col">
            <h1 className="text-lg font-bold text-gray-800 leading-none">DoxaCare</h1>
            <p className="text-[10px] text-green-600 font-bold uppercase tracking-widest mt-0.5">Health Assistant</p>
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-2 sm:space-x-3">
        {/* Language Switcher Toggle */}
        <div className="flex bg-gray-100 p-0.5 rounded-full border border-gray-200 shadow-inner shrink-0">
          <button
            onClick={() => setLanguage(Language.ENGLISH)}
            className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
              language === Language.ENGLISH 
                ? 'bg-green-600 text-white shadow-sm' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            EN
          </button>
          <button
            onClick={() => setLanguage(Language.KRIO)}
            className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
              language === Language.KRIO 
                ? 'bg-green-600 text-white shadow-sm' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            KR
          </button>
        </div>

        {/* User Auth Portal Actions */}
        {currentUser ? (
          <div className="flex items-center space-x-1.5 sm:space-x-2">
            <button
              onClick={() => onNavigateToView?.('chats')}
              className={`w-9 h-9 rounded-full flex items-center justify-center border font-bold text-xs transition active:scale-90 cursor-pointer ${
                view === 'chats' 
                  ? 'bg-green-50 text-green-700 border-green-200' 
                  : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
              }`}
              title={isKrio ? "Mi Symptom Chats" : "My Symptom Chats"}
            >
              <i className="fas fa-comment shadow-inner text-sm"></i>
            </button>

            <button
              onClick={onSignOut}
              className="w-9 h-9 bg-red-50 hover:bg-red-100 text-red-600 border border-red-100 rounded-full flex items-center justify-center transition focus:outline-none active:scale-90 cursor-pointer"
              title={isKrio ? "Sign Out" : "Sign Out"}
            >
              <i className="fas fa-sign-out-alt text-xs"></i>
            </button>
          </div>
        ) : (
          <button
            onClick={() => onNavigateToView?.('login')}
            className={`text-xs font-black px-3.5 py-2 rounded-full flex items-center space-x-1.5 transition cursor-pointer ${
              view === 'login' 
                ? 'bg-green-50 text-green-700 border border-green-100' 
                : 'bg-green-600 hover:bg-green-700 text-white shadow-sm'
            }`}
          >
            <i className="fas fa-user-circle text-sm"></i>
            <span className="hidden sm:inline">{isKrio ? "Log In" : "Sign In"}</span>
          </button>
        )}

        <a 
          href="tel:117" 
          className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-full text-xs font-bold flex items-center shadow-lg transition-transform active:scale-95 shrink-0"
          title="Emergency 117"
        >
          <i className="fas fa-phone-alt animate-pulse"></i>
          <span className="ml-2 hidden sm:inline">117</span>
        </a>
      </div>
    </header>
  );
};

export default Header;

