import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language } from '../types';
import { lookupMedicationDetails } from '../geminiService';

interface Medication {
  id: string;
  name: string;
  class: string;
  uses: string;
  usesKrio: string;
  dosage: string;
  dosageKrio: string;
  sideEffects: string[];
  warnings: string;
  warningsKrio: string;
  clinicalGuidanceSL: string;
}

const LOCAL_MEDICATIONS: Medication[] = [
  {
    id: 'coartem',
    name: 'Coartem (Artemether / Lumefantrine)',
    class: 'ACT (Artemisinin-based Combination Therapy) / Antimalarial',
    uses: 'First-line treatment for uncomplicated Plasmodium falciparum malaria in Sierra Leone.',
    usesKrio: 'Di primary marasin fɔ treat malaria wey de kam frɔm fɛvɛ na Sierra Leone.',
    dosage: 'Take with food or milk. High fat meal boosts absorption. Complete the full 3-day course (6 doses) even if symptoms resolve.',
    dosageKrio: 'Drink am wit ɛg or milk fɔ help am wok fɛn. No stop kɔs pas 3 deys bɔk-bɔk.',
    sideEffects: ['Headache', 'Dizziness', 'Loss of appetite', 'Joint or muscle pain'],
    warnings: 'Contraindicated in first trimester of pregnancy unless no other antimalarial is available. Follow National Malaria Control Programme guidelines.',
    warningsKrio: 'Mami wey gɛt bɛlɛ na fɔst tri mɔnt no fɔ drink am pas dɔkta sey so.',
    clinicalGuidanceSL: 'Distributed FREE to pregnant women, lactating mothers, and children under 5 years under the Sierra Leone Free Health Care Initiative.'
  },
  {
    id: 'ribavirin',
    name: 'Ribavirin',
    class: 'Antiviral Agent',
    uses: 'Strictly utilized for suspected or laboratory-confirmed Lassa Fever cases.',
    usesKrio: 'Marasin wey dɔkta de gi fɔ Lassa Fevɛ case na hospital.',
    dosage: 'Administered intravenously or orally under intensive clinical supervision inside containment units (e.g., Kenema Government Hospital).',
    dosageKrio: 'Dɔkta de gi am tru drip or tɛm wey yu de insay special room na hospital.',
    sideEffects: ['Hemolytic anemia', 'Nausea', 'Fatigue', 'Insomnia', 'Rash'],
    warnings: 'Highly teratogenic (causes birth defects). Avoid pregnancy immediately during treatment. Requires extreme hydration.',
    warningsKrio: 'E bɛd fɔ mami wey gɛt bɛlɛ (e de spɔy pikin inside bɛlɛ). Bɛlɛ mami nɔ fɔ tɔch am at all.',
    clinicalGuidanceSL: 'Regulated and restricted item. Exclusively handled in authorized treatment clinics (Kenema and Panguma Lassa Units). Critical diagnostics must precede administration.'
  },
  {
    id: 'paracetamol',
    name: 'Paracetamol (Acetaminophen)',
    class: 'Analgesic / Antipyretic',
    uses: 'Relief of mild-to-moderate pain and reduction of fever. (Commonly used alongside malaria treatments).',
    usesKrio: 'Mazin wey de kɔt bodipen, kɔf, ɛn fɛvɛ quick quick.',
    dosage: 'Adults: 500mg-1g every 4-6 hours. Maximum 4g (4000mg) per 24 hours. Pediatrics requires weight-based liquid dosage.',
    dosageKrio: 'Big pipul: 1 or 2 tab hɛvri 4 tɛm. No pas fɔ drink 8 tab na wan dey. Pikin gɛt syrrupi dry-cup.',
    sideEffects: ['Rare in standard therapeutic doses', 'Liver toxicity if maximum daily limit exceeded'],
    warnings: 'Avoid liver toxicity: Do not combine with other products containing acetaminophen or with local alcohol (poyo).',
    warningsKrio: 'No drink am pas wetin dɔkta sey, e go spɔy yu liva. No miks am wit alcohol.',
    clinicalGuidanceSL: 'Universally available over-the-counter (OTC) in every peripheral health unit (PHU) and local pharmacy in Sierra Leone.'
  },
  {
    id: 'amoxicillin',
    name: 'Amoxicillin',
    class: 'Penicillin Antibiotic',
    uses: 'Bacterial infections of the respiratory tract, urinary tract, and ear/throat infections.',
    usesKrio: 'Antibiɔtik fɔ fight bad jɛms na lɔns, pish-road, ɔ throat.',
    dosage: 'Adults: 250mg-500mg every 8 hours. Correct course is usually 5-7 days. Must finish the entire course to prevent antibiotic resistance.',
    dosageKrio: 'Big pupul: drink am 3 tɛm fɔ wan dey. Yu mɔs drink di marasin te e dɔn fɔ tap resistant bacteria.',
    sideEffects: ['Diarrhea', 'Nausea', 'Skin rash or itching', 'Oral thrush'],
    warnings: 'Do not use if you have an allergy to Penicillin. May trigger severe anaphylaxis.',
    warningsKrio: 'Mɔs nɔ drink am if yu bodi nɔ de gɛt Penicillin or skin itch yu tɛm wey yu drink Penicillin fɔst.',
    clinicalGuidanceSL: 'Prescription-only medication. Requires professional medical diagnostic review before sale. Misuse worsens local community resistance.'
  },
  {
    id: 'ors_zinc',
    name: 'ORS (Oral Rehydration Salts) + Zinc',
    class: 'Electrolyte Replenisher & Mineral Supplement',
    uses: 'Management of acute watery diarrhea and dehydration (e.g., during suspected Cholera outbreaks).',
    usesKrio: 'Sɔl-ɛn-shuga wata wit Zinc fɔ stop deydrayshun tɛm we mɔt-pisin de run.',
    dosage: 'ORS: Dissolve 1 sachet in exactly 1 Liter of clean safe drinking water; sip continuously. Zinc: 20mg daily for 10-14 days for children.',
    dosageKrio: 'ORS: mɛt wan pɔkɛt inside 1 lita krin wata fɔ drink. Zinc tablet na fɔ 10 to 14 days.',
    sideEffects: ['Vomiting if consumed too rapidly (ORS)', 'Metallic taste (Zinc)'],
    warnings: 'ORS solution must be discarded and remade fresh after 24 hours. Ensure water source is fully boiled or purified.',
    warningsKrio: 'If di wata pas 24 hours, trɔ we am mek yu mek nyu wan. Mɔs use krin boiled wata.',
    clinicalGuidanceSL: 'Distributed immediately in communities during cholera alerts. Found in all PHUs and under Free Health Care protocols.'
  },
  {
    id: 'folic_iron',
    name: 'Ferrous Sulfate + Folic Acid',
    class: 'Anemia Prevention / Prenatal Supplement',
    uses: 'Prevention and treatment of iron deficiency anemia in pregnant ladies in Sierra Leone.',
    usesKrio: 'Ayɔn mazin na fɔ gi bɛlɛ mami bɔk-bɔk blɔt so di pikin go de krin.',
    dosage: '1 tablet daily throughout pregnancy, preferably taken with water or orange juice on an empty stomach.',
    dosageKrio: 'Drink 1 tab hɛvri dey tɛm weyu gɛt bɛlɛ, bɛtɛ fɔ drink am wit orange fɔ help absorb fine.',
    sideEffects: ['Dark colored stools', 'Constipation', 'Nausea or stomach upset'],
    warnings: 'Keep out of reach of children (acute iron overdose is child-emergency). May cause mild constipation.',
    warningsKrio: 'Kip am far frɔm smɔl pikin dɛn, di red kɔlɔ fit mek dɛn tink sɔm sweet.',
    clinicalGuidanceSL: 'Essential component of routine antenatal care (ANC) delivered free at PCMH and public health clinics across the country.'
  }
];

interface MedicationsViewProps {
  language: Language;
  onBack: () => void;
}

const MedicationsView: React.FC<MedicationsViewProps> = ({ language, onBack }) => {
  const isKrio = language === Language.KRIO;
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Medication[]>(LOCAL_MEDICATIONS);
  const [selectedMed, setSelectedMed] = useState<Medication | null>(null);
  const [isSearchingAI, setIsSearchingAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    if (!query.trim()) {
      setSearchResults(LOCAL_MEDICATIONS);
      return;
    }

    const filtered = LOCAL_MEDICATIONS.filter(med => 
      med.name.toLowerCase().includes(query.toLowerCase()) || 
      med.class.toLowerCase().includes(query.toLowerCase())
    );
    setSearchResults(filtered);
  };

  const handleLookupCustomAI = async () => {
    if (!searchQuery.trim()) return;
    setIsSearchingAI(true);
    setAiError(null);
    setSelectedMed(null);

    try {
      const data = await lookupMedicationDetails(searchQuery, isKrio ? "Krio and English" : "English with Krio translations");
      
      const customMed: Medication = {
        id: 'ai_' + Date.now(),
        name: data.name || searchQuery,
        class: data.class || 'Unknown Class',
        uses: data.uses,
        usesKrio: data.usesKrio || data.uses,
        dosage: data.dosage,
        dosageKrio: data.dosageKrio || data.dosage,
        sideEffects: data.sideEffects || [],
        warnings: data.warnings,
        warningsKrio: data.warningsKrio || data.warnings,
        clinicalGuidanceSL: data.clinicalGuidanceSL
      };

      setSelectedMed(customMed);
    } catch (err) {
      console.error(err);
      setAiError(isKrio ? "Wi nɔ able look up dis marasin na database bin now. Please chɛk di name again." : "We couldn't parse information for this medicine right now. Please check spelling.");
    } finally {
      setIsSearchingAI(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-hidden">
      
      {/* Page Title Header */}
      <div className="bg-white border-b border-gray-100 px-6 py-5 shrink-0">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-green-50 text-green-600 flex items-center justify-center text-lg">
            <i className="fas fa-pills"></i>
          </div>
          <div>
            <h2 className="text-xl font-black text-gray-800 tracking-tight leading-none">
              {isKrio ? "SL Marasin Directory" : "National Med Directory"}
            </h2>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1.5">
              {isKrio ? "Safety & Free Healthcare guide" : "Essential Medicines & Safety Lookup"}
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        
        {/* Search Bar section */}
        <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm relative">
          <div className="flex items-center space-x-2 bg-gray-50 border border-gray-200 rounded-2xl px-4 py-1.5 focus-within:ring-2 focus-within:ring-green-500 focus-within:border-green-500 transition-all">
            <i className="fas fa-search text-gray-400 shrink-0 text-sm"></i>
            <input
              type="text"
              value={searchQuery}
              onChange={handleSearchChange}
              placeholder={isKrio ? "Type marasin name (e.g., Coartem, ACT, panadol)..." : "Search standard catalog or input any medication..."}
              className="flex-1 bg-transparent py-2.5 focus:outline-none text-gray-800 text-sm"
            />
            {searchQuery.trim() && (
              <button 
                onClick={() => { setSearchQuery(''); setSearchResults(LOCAL_MEDICATIONS); setSelectedMed(null); }}
                className="w-6 h-6 rounded-full bg-gray-200 hover:bg-gray-300 text-gray-600 flex items-center justify-center text-[10px]"
              >
                <i className="fas fa-times"></i>
              </button>
            )}
          </div>

          <AnimatePresence>
            {searchQuery.trim() && searchResults.length === 0 && (
              <motion.div 
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 5 }}
                className="mt-4 pt-3 border-t border-gray-100 text-center"
              >
                <p className="text-xs text-gray-500 mb-3 font-semibold">
                  {isKrio ? `No marasin na standard list wey dɛn tink "${searchQuery}"` : `No local results found matching "${searchQuery}"`}
                </p>
                <button
                  onClick={handleLookupCustomAI}
                  disabled={isSearchingAI}
                  className="bg-green-600 hover:bg-green-700 disabled:bg-gray-300 text-white text-xs font-black px-4 py-3 rounded-2xl shadow-md transition-all active:scale-95 flex items-center justify-center space-x-2 mx-auto"
                >
                  {isSearchingAI ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>{isKrio ? "Doxa de analyze..." : "Querying Clinical AI..."}</span>
                    </>
                  ) : (
                    <>
                      <i className="fas fa-brain"></i>
                      <span>{isKrio ? "Ask Doxa AI fɔ search am global database" : "Query Global Clinical Database"}</span>
                    </>
                  )}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {aiError && (
          <div className="p-4 bg-red-50 border border-red-100 text-red-800 text-xs font-bold rounded-2xl flex items-start space-x-2">
            <i className="fas fa-exclamation-circle mt-0.5 shrink-0"></i>
            <span>{aiError}</span>
          </div>
        )}

        {/* Selected custom lookup card details */}
        {selectedMed && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl border-2 border-green-500 shadow-xl p-6 space-y-6"
          >
            <div className="flex justify-between items-start border-b border-gray-100 pb-4">
              <div>
                <span className="inline-block bg-green-100 text-green-800 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full mb-2">
                  Clinical AI Response
                </span>
                <h3 className="text-xl font-black text-gray-800 leading-none">{selectedMed.name}</h3>
                <p className="text-xs font-semibold text-gray-400 mt-1.5">{selectedMed.class}</p>
              </div>
              <button 
                onClick={() => setSelectedMed(null)}
                className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-500 flex items-center justify-center"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            <div className="grid grid-cols-1 gap-5">
              <div className="space-y-1.5">
                <span className="block text-xs font-extrabold text-green-700 tracking-wide uppercase">
                  {isKrio ? "Wetin e go do fɔ yu (Uses):" : "Medical Indications (What it treats):"}
                </span>
                <p className="text-sm text-gray-700 bg-gray-50 p-3.5 rounded-2xl border border-gray-100 font-medium">
                  {isKrio ? selectedMed.usesKrio : selectedMed.uses}
                </p>
              </div>

              <div className="space-y-1.5">
                <span className="block text-xs font-extrabold text-green-700 tracking-wide uppercase">
                  {isKrio ? "Safe Dose Guidance:" : "Standard Dosage Guidance:"}
                </span>
                <p className="text-sm text-gray-700 bg-gray-50 p-3.5 rounded-2xl border border-gray-100 font-medium whitespace-pre-line">
                  {isKrio ? selectedMed.dosageKrio : selectedMed.dosage}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <span className="block text-xs font-extrabold text-red-600 tracking-wide uppercase">
                    {isKrio ? "Danjas & Caution (Warnings):" : "Contraindications / Critical Warnings:"}
                  </span>
                  <div className="p-3.5 bg-red-50/50 border border-red-100 rounded-2xl text-xs font-semibold text-red-800 whitespace-pre-line">
                    {isKrio ? selectedMed.warningsKrio : selectedMed.warnings}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="block text-xs font-extrabold text-blue-700 tracking-wide uppercase">
                    {isKrio ? "Free Health status nɔ Salone:" : "Sierra Leone Clinical Availability:"}
                  </span>
                  <div className="p-3.5 bg-blue-50/50 border border-blue-100 rounded-2xl text-xs font-semibold text-blue-800">
                    {selectedMed.clinicalGuidanceSL}
                  </div>
                </div>
              </div>

              {selectedMed.sideEffects.length > 0 && (
                <div className="space-y-2 pt-1">
                  <span className="block text-xs font-extrabold text-gray-500 tracking-wide uppercase">
                    Common Side Effects:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {selectedMed.sideEffects.map((effect, idx) => (
                      <span key={idx} className="bg-gray-100 text-gray-700 text-xs px-3 py-1.5 rounded-xl font-medium border border-gray-200">
                        • {effect}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* Local Medication Catalog List */}
        {!selectedMed && (
          <div className="space-y-4">
            <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest pl-1">
              {isKrio ? "Sierra Leone Essential Catalog dɛn" : "Essential Local Registries"} ({searchResults.length})
            </h3>

            <div className="grid grid-cols-1 gap-4">
              {searchResults.map((med) => (
                <div
                  key={med.id}
                  onClick={() => setSelectedMed(med)}
                  className="bg-white hover:bg-gray-50 active:scale-99 transition-all p-5 rounded-3xl border border-gray-100 shadow-sm cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 group"
                >
                  <div className="space-y-1.5 flex-1 max-w-xl">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-green-500"></span>
                      <h4 className="text-base font-black text-gray-800 leading-none group-hover:text-green-600 transition-colors">
                        {med.name}
                      </h4>
                    </div>
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-wide">
                      {med.class}
                    </p>
                    <p className="text-xs text-gray-500 font-medium line-clamp-2">
                      {isKrio ? med.usesKrio : med.uses}
                    </p>
                  </div>

                  <div className="flex items-center justify-end">
                    <span className="text-[10px] font-black text-green-600 uppercase bg-green-50 border border-green-100 px-3 py-1.5 rounded-full inline-flex items-center space-x-1 shrink-0">
                      <span>View Safety Profile</span>
                      <i className="fas fa-chevron-right ml-1"></i>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default MedicationsView;
