import React, { useState } from 'react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  GoogleAuthProvider,
  updateProfile 
} from 'firebase/auth';
import { auth } from '../firebase';
import { Language } from '../types';

interface AuthViewProps {
  language: Language;
  onSuccess: () => void;
  onBack: () => void;
}

const AuthView: React.FC<AuthViewProps> = ({ language, onSuccess, onBack }) => {
  const isKrio = language === Language.KRIO;
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errMessage, setErrMessage] = useState<string | null>(null);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    setIsLoading(true);
    setErrMessage(null);

    try {
      if (mode === 'signup') {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        if (displayName) {
          await updateProfile(userCredential.user, { displayName });
        }
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      onSuccess();
    } catch (err: any) {
      console.error("Auth error:", err);
      let errorFriendly = err.message;
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
        errorFriendly = isKrio ? "Email or password no correct. Tri again." : "Incorrect email or password. Please try again.";
      } else if (err.code === 'auth/email-already-in-use') {
        errorFriendly = isKrio ? "Dat email address de use already." : "This email address is already in use.";
      } else if (err.code === 'auth/weak-password') {
        errorFriendly = isKrio ? "Di pasword too short or weak. E must list 6 letters." : "Password is too weak. Must be at least 6 characters.";
      } else if (err.code === 'auth/invalid-email') {
        errorFriendly = isKrio ? "Email format no correct. Check am fine." : "Invalid email address format.";
      }
      setErrMessage(errorFriendly);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    setIsLoading(true);
    setErrMessage(null);
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      onSuccess();
    } catch (err: any) {
      console.error("Google auth error", err);
      if (err.code !== 'auth/popup-closed-by-user') {
        setErrMessage(err.message);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-center items-center bg-gray-50 px-6 py-8 overflow-y-auto">
      <div className="w-full max-w-md bg-white rounded-[32px] border border-gray-100 shadow-xl p-8 relative">
        
        {/* Back Button */}
        <button 
          onClick={onBack}
          className="absolute top-6 left-6 w-9 h-9 rounded-full bg-gray-150 hover:bg-gray-100 flex items-center justify-center text-gray-500 transition-colors"
        >
          <i className="fas fa-chevron-left"></i>
        </button>

        <div className="text-center mt-4 mb-8">
          <div className="w-16 h-16 rounded-2xl bg-green-50 text-green-600 flex items-center justify-center text-2xl mx-auto mb-4">
            <i className="fas fa-user-shield"></i>
          </div>
          <h2 className="text-2xl font-black text-gray-800 tracking-tight leading-none">
            {mode === 'signin' 
              ? (isKrio ? "Log In DoxaCare" : "Sign In to DoxaCare")
              : (isKrio ? "Kriet Account" : "Create Account")}
          </h2>
          <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-2">
            {isKrio ? "Sɛv yu records securely cloud" : "Secure Clinical Portal for Sierra Leone"}
          </p>
        </div>

        {errMessage && (
          <div className="mb-4 p-4 bg-red-50 border border-red-100 text-red-800 text-xs font-semibold rounded-2xl flex items-start space-x-3">
            <i className="fas fa-exclamation-circle mt-0.5 text-red-600 shrink-0"></i>
            <span>{errMessage}</span>
          </div>
        )}

        {/* Auth form */}
        <form onSubmit={handleEmailAuth} className="space-y-4">
          {mode === 'signup' && (
            <div>
              <label className="block text-xs font-black text-gray-400 uppercase tracking-wide mb-1.5 pl-1">
                {isKrio ? "Yu Name" : "Display Name"}
              </label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder={isKrio ? "John Kamara" : "Full Name"}
                className="w-full bg-gray-50 border border-gray-200 focus:border-green-500 focus:ring-1 focus:ring-green-500 rounded-2xl px-4 py-3 text-sm text-gray-800 focus:outline-none transition-all pl-10 relative"
              />
              <span className="absolute -mt-8.5 ml-4 text-gray-400">
                <i className="fas fa-user text-xs"></i>
              </span>
            </div>
          )}

          <div className="relative">
            <label className="block text-xs font-black text-gray-400 uppercase tracking-wide mb-1.5 pl-1">
              {isKrio ? "Email Address" : "Email Address"}
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@gmail.com"
              required
              className="w-full bg-gray-50 border border-gray-200 focus:border-green-500 focus:ring-1 focus:ring-green-500 rounded-2xl px-4 py-3 text-sm text-gray-800 focus:outline-none transition-all pl-10"
            />
            <span className="absolute bottom-3.5 left-4 text-gray-400">
              <i className="fas fa-envelope text-xs"></i>
            </span>
          </div>

          <div className="relative">
            <label className="block text-xs font-black text-gray-400 uppercase tracking-wide mb-1.5 pl-1">
              {isKrio ? "Pasword" : "Password"}
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              minLength={6}
              className="w-full bg-gray-50 border border-gray-200 focus:border-green-500 focus:ring-1 focus:ring-green-500 rounded-2xl px-4 py-3 text-sm text-gray-800 focus:outline-none transition-all pl-10"
            />
            <span className="absolute bottom-3.5 left-4 text-gray-400">
              <i className="fas fa-lock text-xs"></i>
            </span>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-green-600 hover:bg-green-700 text-white font-extrabold py-3.5 rounded-2xl shadow-md hover:shadow-lg hover:shadow-green-100 transition duration-300 active:scale-95 text-sm flex items-center justify-center space-x-2"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <i className={mode === 'signin' ? "fas fa-sign-in-alt" : "fas fa-user-plus"}></i>
                <span>
                  {mode === 'signin' 
                    ? (isKrio ? "Sign In na DoxaCare" : "Sign In to Doxa") 
                    : (isKrio ? "Register Account" : "Register and Create")}
                </span>
              </>
            )}
          </button>
        </form>

        {/* Divider separator */}
        <div className="relative flex items-center justify-center my-6">
          <div className="absolute w-full border-t border-gray-100"></div>
          <span className="relative bg-white px-3 text-[10px] font-black text-gray-400 uppercase tracking-wider">
            {isKrio ? "Or use" : "OR CONTINUE WITH"}
          </span>
        </div>

        {/* Google Popup sign in */}
        <button
          onClick={handleGoogleAuth}
          disabled={isLoading}
          className="w-full border border-gray-200 hover:bg-gray-50 font-bold py-3.5 rounded-2xl shadow-sm text-gray-700 text-sm flex items-center justify-center space-x-2.5 transition active:scale-95"
        >
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/smartlock/iframe/google.svg" alt="Google" className="w-4 h-4" />
          <span>{isKrio ? "Log in wit Google" : "Continue with Google"}</span>
        </button>

        {/* Toggle Mode */}
        <div className="text-center mt-6">
          <button
            onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')}
            className="text-xs font-semibold text-green-600 hover:text-green-700 underline focus:outline-none"
          >
            {mode === 'signin'
              ? (isKrio ? "Yu nɔ gɛt account? Regista fɔ free!" : "Don't have an account? Sign up free!")
              : (isKrio ? "Yu gɛt account ready? Log in ya!" : "Already have an account? Sign in here!")}
          </button>
        </div>

      </div>
    </div>
  );
};

export default AuthView;
