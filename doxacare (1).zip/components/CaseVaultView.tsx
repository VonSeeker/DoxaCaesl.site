import React, { useState, useEffect } from 'react';
import { Language, SavedCase } from '../types';

interface CaseVaultViewProps {
  language: Language;
  onBackToWellness?: () => void;
}

const CaseVaultView: React.FC<CaseVaultViewProps> = ({ language, onBackToWellness }) => {
  const isKrio = language === Language.KRIO;
  const [cases, setCases] = useState<SavedCase[]>([]);
  const [filter, setFilter] = useState<'ALL' | 'RED' | 'YELLOW' | 'GREEN'>('ALL');
  const [expandedCaseId, setExpandedCaseId] = useState<string | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('doxacare_saved_cases');
      if (saved) {
        setCases(JSON.parse(saved));
      }
    } catch (err) {
      console.error("Could not load case logs", err);
    }
  }, []);

  const handleDeleteCase = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(isKrio ? "Yu sure say yu wan delete dis report?" : "Are you sure you want to delete this clinical report?")) {
      const updated = cases.filter(c => c.id !== id);
      setCases(updated);
      localStorage.setItem('doxacare_saved_cases', JSON.stringify(updated));
    }
  };

  const handleClearAll = () => {
    if (confirm(isKrio ? "Delete all saved briefs?" : "Are you sure you want to permanently clear all saved clinical briefs?")) {
      setCases([]);
      localStorage.removeItem('doxacare_saved_cases');
    }
  };

  const filteredCases = cases.filter(c => {
    if (filter === 'ALL') return true;
    return c.clinicalTriage === filter;
  });

  return (
    <div className="flex-1 overflow-y-auto bg-gray-50 p-6">
      {/* Title Header */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-3">
          <div className="text-emerald-600 text-2xl">
            <i className="fas fa-book-medical"></i>
          </div>
          <div>
            <h2 className="text-2xl font-black text-gray-800">
              {isKrio ? "Mi Doctor Briefs" : "My Case Book"}
            </h2>
            <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">
              {isKrio ? "Yu Saved Assessment Records" : "Your Saved Assessment Portfolio"}
            </p>
          </div>
        </div>
        {cases.length > 0 && (
          <button
            onClick={handleClearAll}
            className="text-xs font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100/80 px-3 py-1.5 rounded-full transition-colors"
          >
            Clear All
          </button>
        )}
      </div>

      <p className="text-gray-500 text-sm mb-6 leading-relaxed">
        {isKrio
          ? "Show dis screens to any Nurse, Doctor or Pharmacist na Sierra Leone fɔ help dem run the correct tests or make fast decisions fɔ yu health."
          : "These reports help bridge the gap. Present these precise briefings to caregivers at any Clinical Health Post, District Hospital, or Pharmacy to guide your care."}
      </p>

      {/* Info Alert on Offline Use */}
      <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl flex items-start space-x-3 mb-6">
        <div className="text-emerald-600 mt-0.5">
          <i className="fas fa-wifi"></i>
        </div>
        <div>
          <span className="text-xs font-bold text-emerald-900 block uppercase tracking-wide">
            {isKrio ? "Dɔn design fɔ Offline Use" : "Works Fully Offline"}
          </span>
          <span className="text-xs text-emerald-800 block opacity-90 leading-normal">
            {isKrio
              ? "Dis health records de sɛv na yu device securely. Yu nɔ nid internet fɔ show am to di doctor inside clinic."
              : "All briefings are stored on your device's memory. You don't need active network, 4G, or data to present them later."}
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      {cases.length > 0 && (
        <div className="flex space-x-1 pl-1 bg-gray-100 p-1 rounded-2xl mb-6 max-w-sm">
          {(['ALL', 'RED', 'YELLOW', 'GREEN'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`flex-1 py-1.5 rounded-xl text-[10px] font-extrabold uppercase transition-all tracking-wider ${
                filter === tab 
                  ? 'bg-white text-gray-800 shadow-sm' 
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      )}

      {/* Empty State */}
      {filteredCases.length === 0 ? (
        <div className="bg-white rounded-[32px] border border-gray-100 p-12 text-center shadow-sm">
          <div className="w-16 h-16 bg-gray-50 text-gray-300 rounded-2xl flex items-center justify-center mx-auto mb-4 text-2xl">
            <i className="fas fa-folder-open"></i>
          </div>
          <h4 className="font-bold text-gray-700 mb-1">
            {isKrio ? "No briefs sɛv yet" : "No briefings saved"}
          </h4>
          <p className="text-gray-400 text-xs max-w-xs mx-auto mb-6">
            {isKrio
              ? "Afta yu query any health symptom check, click 'Generate Doctor Clinical Brief' to log briefs na yu phone."
              : "After assessing any symptomatology, select generated briefs to save your clinical dossier."}
          </p>
          {onBackToWellness && (
            <button
              onClick={onBackToWellness}
              className="bg-green-600 hover:bg-green-700 text-white font-bold px-6 py-3 rounded-full text-xs shadow-md transition active:scale-95"
            >
              {isKrio ? "Start new symptom check" : "Check symptoms now"}
            </button>
          )}
        </div>
      ) : (
        /* List of Saved Cases */
        <div className="space-y-4">
          {filteredCases.map(item => {
            const hasBriefDetails = item.labDiagnosticTests && item.labDiagnosticTests.length > 0;
            const isExpanded = expandedCaseId === item.id;
            const formattedDate = new Date(item.timestamp).toLocaleDateString(undefined, {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            });

            return (
              <div 
                key={item.id}
                onClick={() => setExpandedCaseId(isExpanded ? null : item.id)}
                className={`bg-white rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden cursor-pointer ${
                  isExpanded ? 'ring-2 ring-emerald-500/20' : ''
                }`}
              >
                {/* Header section of Case Card */}
                <div className="p-5 flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white shrink-0 ${
                      item.clinicalTriage === 'RED' 
                        ? 'bg-red-500 shadow-red-100 shadow-lg' 
                        : item.clinicalTriage === 'YELLOW'
                          ? 'bg-amber-500 shadow-amber-100 shadow-lg'
                          : 'bg-green-500 shadow-green-100 shadow-lg'
                    }`}>
                      <i className="fas fa-clinic-medical"></i>
                    </div>
                    <div>
                      <h4 className="font-extrabold text-gray-800 text-base leading-tight">
                        {item.topic}
                      </h4>
                      <p className="text-gray-400 text-[10px] uppercase font-bold tracking-wider mt-1 flex items-center space-x-2">
                        <span>{formattedDate}</span>
                        <span>•</span>
                        <span className={
                          item.clinicalTriage === 'RED'
                            ? 'text-red-500'
                            : item.clinicalTriage === 'YELLOW'
                              ? 'text-amber-500'
                              : 'text-green-500'
                        }>{item.clinicalTriage}</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={(e) => handleDeleteCase(item.id, e)}
                      className="w-8 h-8 rounded-full hover:bg-red-50 text-gray-300 hover:text-red-500 flex items-center justify-center transition-colors"
                    >
                      <i className="fas fa-trash-alt text-xs"></i>
                    </button>
                    <div className="text-gray-400 pl-1">
                      <i className={`fas ${isExpanded ? 'fa-chevron-up' : 'fa-chevron-down'} text-xs`}></i>
                    </div>
                  </div>
                </div>

                {/* Expanded Case Body details */}
                {isExpanded && (
                  <div className="px-5 pb-5 pt-1 border-t border-gray-50 bg-gray-50/50 space-y-4 text-xs select-text">
                    
                    {/* General Suspected Diagnosis */}
                    <div>
                      <h5 className="font-extrabold text-gray-400 uppercase tracking-wider mb-1.5 flex items-center">
                        <i className="fas fa-stethoscope text-emerald-600 mr-2"></i>
                        {isKrio ? "Primary Analysis Details" : "Primary Analysis Indications"}
                      </h5>
                      <div className="flex flex-wrap gap-1.5">
                        {item.conditions.map((c, i) => (
                          <span key={i} className="bg-white border border-gray-100 text-gray-700 px-3 py-1.5 rounded-xl font-bold">
                            {c.name}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Timeline & Preg status */}
                    {item.patientDetails && (
                      <div className="grid grid-cols-2 gap-3 bg-white p-3.5 rounded-2xl border border-gray-100">
                        <div>
                          <span className="block text-[10px] text-gray-400 uppercase font-black">Timeline</span>
                          <span className="font-bold text-gray-700">{item.patientDetails.timeline}</span>
                        </div>
                        <div>
                          <span className="block text-[10px] text-gray-400 uppercase font-black">Maternal status</span>
                          <span className={`font-bold ${item.patientDetails.isPregnant ? 'text-pink-600' : 'text-gray-700'}`}>
                            {item.patientDetails.isPregnant 
                              ? (isKrio ? 'Expectant (Bɛlɛ)' : 'Pregnant Watch') 
                              : (isKrio ? 'Normal' : 'Non-Maternal')}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Labs and diagnostics */}
                    <div>
                      <h5 className="font-extrabold text-blue-900 uppercase tracking-widest mb-2 flex items-center">
                        <i className="fas fa-microscope text-blue-500 mr-2"></i>
                        {isKrio ? "Recommended Lab Tests" : "Standard Diagnostic Panel"}
                      </h5>
                      <ul className="grid grid-cols-1 md:grid-cols-2 gap-1.5 text-xs">
                        {item.labDiagnosticTests.map((t, idx) => (
                          <li key={idx} className="bg-white border border-blue-100 py-2 px-3 rounded-xl text-gray-600 font-bold flex items-center space-x-2">
                            <span className="w-1 h-1 bg-blue-500 rounded-full shrink-0"></span>
                            <span>{t}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Global Guidelines details */}
                    <div className="bg-white p-4 rounded-2xl border border-gray-100">
                      <span className="text-[9px] uppercase tracking-wider font-extrabold text-emerald-600">Research Guideline Evidence</span>
                      <p className="text-gray-600 leading-relaxed italic mt-1.5 border-l-2 border-emerald-500 pl-2.5">
                        {item.researchGuidelineSummary}
                      </p>
                    </div>

                    {/* Dynamic consultation questions */}
                    <div>
                      <h5 className="font-extrabold text-gray-400 uppercase tracking-wider mb-2 flex items-center">
                        <i className="fas fa-question-circle text-yellow-500 mr-2"></i>
                        {isKrio ? "Questions you should ask caregivers" : "Clinical Inquiries for Patient Care"}
                      </h5>
                      <ul className="space-y-2 text-gray-600">
                        {item.suggestedDoctorQuestions.map((q, idx) => (
                          <li key={idx} className="bg-white border border-gray-100/80 p-2.5 rounded-xl font-semibold leading-relaxed flex items-start">
                            <span className="text-yellow-600 font-bold mr-2">{idx + 1}.</span>
                            <span>{q}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default CaseVaultView;
