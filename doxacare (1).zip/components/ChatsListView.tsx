import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language } from '../types';
import { auth } from '../firebase';
import { fetchUserConversations, FirebaseConversation } from '../firebaseService';

interface ChatsListViewProps {
  language: Language;
  onResumeConversation: (conversationId: string) => void;
  onBackToWellness: () => void;
  onLoginRedirect: () => void;
}

const ChatsListView: React.FC<ChatsListViewProps> = ({ 
  language, 
  onResumeConversation, 
  onBackToWellness, 
  onLoginRedirect 
}) => {
  const isKrio = language === Language.KRIO;
  const [conversations, setConversations] = useState<FirebaseConversation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorText, setErrorText] = useState<string | null>(null);

  const loadConversations = async () => {
    if (!auth.currentUser) {
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    setErrorText(null);
    try {
      const data = await fetchUserConversations();
      setConversations(data);
    } catch (err: any) {
      console.error(err);
      setErrorText(isKrio ? "Eror hapun wey wi de lod chats. Chɛk yu line." : "Failed to load chat history. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadConversations();
  }, []);

  if (!auth.currentUser) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-50 p-6 text-center">
        <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center text-xl mb-4 shadow-inner">
          <i className="fas fa-lock"></i>
        </div>
        <h3 className="text-xl font-black text-gray-800 leading-none">
          {isKrio ? "Sign In fɔ see yu Chats" : "Sign In Required"}
        </h3>
        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-2">
          {isKrio ? "Pasin mɔs authenticate fɔ fetch cloud records" : "Personal Secure Medical Correspondence"}
        </p>
        <p className="text-xs text-gray-400 max-w-xs mt-3 leading-relaxed">
          {isKrio 
            ? "Log in na DoxaCare fɔ resume past health checks and analyze symptom transcripts securely." 
            : "Sign in to securely sync your symptom analysis histories across all devices."}
        </p>
        <button
          onClick={onLoginRedirect}
          className="mt-6 px-6 py-3.5 bg-green-600 hover:bg-green-700 text-white font-extrabold text-sm rounded-2xl shadow transition"
        >
          {isKrio ? "Log In Now" : "Secure Sign In"}
        </button>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-hidden">
      
      {/* Page Title */}
      <div className="bg-white border-b border-gray-100 px-6 py-5 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-green-50 text-green-600 flex items-center justify-center text-lg">
              <i className="fas fa-comments"></i>
            </div>
            <div>
              <h2 className="text-xl font-black text-gray-800 tracking-tight leading-none">
                {isKrio ? "Mi Symptom Chats" : "My Health Chats"}
              </h2>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1.5">
                {isKrio ? "Review saved clinical summaries" : "Review Persistent Consultations"}
              </p>
            </div>
          </div>
          <button
            onClick={onBackToWellness}
            className="px-4 py-2 bg-green-50 hover:bg-green-100/50 text-green-800 font-bold text-xs rounded-xl flex items-center space-x-1.5 transition cursor-pointer"
          >
            <i className="fas fa-plus"></i>
            <span>{isKrio ? "New Chat" : "New Chat"}</span>
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {errorText && (
          <div className="p-4 bg-red-50 border border-red-100 text-red-800 text-xs font-semibold rounded-2xl flex items-start space-x-2">
            <i className="fas fa-exclamation-circle mt-0.5 shrink-0"></i>
            <span>{errorText}</span>
          </div>
        )}

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-green-600 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-xs text-gray-500 font-semibold">{isKrio ? "Doxa de load chats..." : "Pulling persistent chat threads..."}</p>
          </div>
        ) : conversations.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-3xl border border-gray-100 p-6 shadow-sm max-w-sm mx-auto">
            <div className="w-16 h-16 bg-gray-50 text-gray-300 rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <i className="fas fa-comment-slash"></i>
            </div>
            <h4 className="font-extrabold text-gray-800 text-base">{isKrio ? "No chats yet!" : "No Past Health Chats"}</h4>
            <p className="text-xs text-gray-400 mt-2 leading-relaxed">
              {isKrio 
                ? "Yu nɔ analyze symptoms yet fɔ save thread. Go home and describe what you feel." 
                : "Your persistent conversations list is empty. Start a consultation thread to track."}
            </p>
            <button
              onClick={onBackToWellness}
              className="mt-5 px-5 py-3 bg-green-600 hover:bg-green-700 text-white font-extrabold text-xs rounded-2xl shadow transition"
            >
              {isKrio ? "Start Health Check" : "Start Consultation"}
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest pl-1">
              {isKrio ? "Saved Clinical Threads" : "Recent Correspondence"} ({conversations.length})
            </h3>

            <div className="grid grid-cols-1 gap-3">
              <AnimatePresence>
                {conversations.map((convo) => (
                  <motion.div
                    key={convo.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    onClick={() => onResumeConversation(convo.id)}
                    className="bg-white hover:bg-gray-50 active:scale-99 cursor-pointer transition-all p-5 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between group"
                  >
                    <div className="space-y-1.5 flex-1 max-w-md">
                      <div className="flex items-center space-x-2">
                        <span className="w-2 h-2 rounded-full bg-green-500"></span>
                        <h4 className="font-black text-gray-800 text-base leading-none group-hover:text-green-600 transition-colors line-clamp-1">
                          {convo.topic}
                        </h4>
                      </div>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                        Last Active: {new Date(convo.lastMessageAt).toLocaleString()}
                      </p>
                    </div>

                    <div className="flex items-center pl-3">
                      <span className="w-8 h-8 rounded-full bg-gray-50 text-gray-400 flex items-center justify-center text-xs group-hover:bg-green-50 group-hover:text-green-600 transition-colors">
                        <i className="fas fa-chevron-right"></i>
                      </span>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default ChatsListView;
