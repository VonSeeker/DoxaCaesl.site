import React, { useState, useMemo, useEffect, useRef } from 'react';
import { CLINICS } from '../data';
import { Language, Clinic } from '../types';
import { auth } from '../firebase';
import { createBookingRequest } from '../firebaseService';

interface ClinicViewProps {
  language: Language;
  onLoginRedirect?: () => void;
}

const ClinicView: React.FC<ClinicViewProps> = ({ language, onLoginRedirect }) => {
  const [query, setQuery] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [selectedClinicId, setSelectedClinicId] = useState<string | null>(null);

  // Booking states
  const [bookingClinic, setBookingClinic] = useState<Clinic | null>(null);
  const [patientName, setPatientName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [bookingNotes, setBookingNotes] = useState('');
  const [isSubmittingBooking, setIsSubmittingBooking] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState<any>(null);
  const [bookingError, setBookingError] = useState<string | null>(null);

  const handleBookSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingClinic) return;
    if (!patientName || !contactPhone || !bookingDate || !bookingTime) {
      setBookingError(isKrio ? "Fɔl di infɔmayshun fine" : "Please fill in all required fields.");
      return;
    }
    setIsSubmittingBooking(true);
    setBookingError(null);
    try {
      const resp = await createBookingRequest(
        bookingClinic.id,
        bookingClinic.name,
        patientName,
        contactPhone,
        bookingDate,
        bookingTime,
        bookingNotes
      );
      setBookingSuccess(resp);
    } catch (err: any) {
      console.error(err);
      setBookingError(isKrio ? "Eror hapun fɔ book apɔyntmɛnt. Try again." : "Could not complete booking. Please try again.");
    } finally {
      setIsSubmittingBooking(false);
    }
  };
  
  // Offline & Local Storage Caching State
  const [clinics, setClinics] = useState<Clinic[]>(() => {
    const cached = localStorage.getItem('doxacare_clinics_cache');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error('Failed to parse cached clinics', e);
      }
    }
    return CLINICS;
  });

  const [savedClinicIds, setSavedClinicIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('doxacare_saved_clinics');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved clinics', e);
      }
    }
    // Deep fallback: Pre-save Connaught and Bo Regional Hospitals so users see immediate samples
    return ['1', '4'];
  });

  const [filterSavedOnly, setFilterSavedOnly] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });
  const [toast, setToast] = useState<string | null>(null);
  const toastTimeoutRef = useRef<any>(null);

  const mapRef = useRef<any>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<{ [key: string]: any }>({});
  const isKrio = language === Language.KRIO;

  // Synced cached copy of all clinics
  useEffect(() => {
    localStorage.setItem('doxacare_clinics_cache', JSON.stringify(clinics));
  }, [clinics]);

  // Monitor network status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      showToast(isKrio ? "Yu de na line naw! Map dɛn dɔn ready." : "You are back online! Interactive maps are active.");
    };
    const handleOffline = () => {
      setIsOnline(false);
      showToast(isKrio ? "Sistem offline. Luk mɛdisin ples dɛn we yu sɛv!" : "You are offline. Accessing cached local directory.");
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [isKrio]);

  // Toast notifier
  const showToast = (message: string) => {
    if (toastTimeoutRef.current) {
      clearTimeout(toastTimeoutRef.current);
    }
    setToast(message);
    toastTimeoutRef.current = setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Toggle Save Clinic for Offline View
  const toggleSaveClinic = (id: string, name: string) => {
    setSavedClinicIds(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      localStorage.setItem('doxacare_saved_clinics', JSON.stringify(next));
      if (prev.includes(id)) {
        showToast(isKrio ? `Pull ${name} commɔt na di offline list.` : `Removed ${name} from offline cache.`);
      } else {
        showToast(isKrio ? `Sɛv ${name} fɔ view offline!` : `Saved ${name} for offline access!`);
      }
      return next;
    });
  };

  // Extract unique districts for the filter (based on cached/current data list)
  const districts = useMemo(() => {
    const dists = Array.from(new Set(clinics.map(c => c.district))).sort();
    return dists;
  }, [clinics]);

  // Extract unique clinic types for the filter
  const clinicTypes = useMemo(() => {
    const types = Array.from(new Set(clinics.map(c => c.type))).sort();
    return types;
  }, [clinics]);

  const translateType = (type: string) => {
    if (!isKrio) return type;
    const mapping: { [key: string]: string } = {
      'Government Referral Hospital': 'Big Gɔvnmɛnt Osptul',
      'Maternity Hospital': 'Mama ɛn Pikin Osptul',
      'Children’s Hospital': 'Pikin Osptul',
      'Government Regional Hospital': 'Gɔvnmɛnt Osptul na di Provins',
      'Addiction & Mental Health Centre': 'Ples fɔ Kush ɛp',
      'Mental Health Facility': 'Ples fɔ Krase biznɛs',
      'Military Hospital': 'Sɔja Osptul',
      'Government District Hospital': 'Gɔvnmɛnt Distrikt Osptul',
      'Pharmacy': 'Famasi',
      'Mission Hospital': 'Mishɔn Osptul',
      'Referral Hospital': 'Rɛfral Osptul',
      'Government Health Facility': 'Gɔvnmɛnt Ɛlt Ples',
      'Government Health Centre': 'Gɔvnmɛnt Ɛlt Sɛnta'
    };
    return mapping[type] || type;
  };

  const filteredClinics = useMemo(() => {
    const q = query.toLowerCase();
    return clinics.filter(c => {
      const matchesSearch = 
        c.name.toLowerCase().includes(q) ||
        c.location.toLowerCase().includes(q) ||
        c.district.toLowerCase().includes(q) ||
        c.type.toLowerCase().includes(q) ||
        (c.description && c.description.toLowerCase().includes(q));
      
      const matchesDistrict = selectedDistrict === 'all' || c.district === selectedDistrict;
      const matchesType = selectedType === 'all' || c.type === selectedType;
      const matchesSavedFilter = !filterSavedOnly || savedClinicIds.includes(c.id);
      
      return matchesSearch && matchesDistrict && matchesType && matchesSavedFilter;
    });
  }, [query, selectedDistrict, selectedType, clinics, filterSavedOnly, savedClinicIds]);

  const handlePrint = () => {
    window.print();
  };

  // Map initialization - Only if online
  useEffect(() => {
    if (viewMode === 'map' && isOnline && mapContainerRef.current && !mapRef.current) {
      // @ts-ignore
      const L = window.L;
      if (L) {
        const map = L.map(mapContainerRef.current).setView([8.484, -13.234], 12);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);
        
        mapRef.current = map;
      }
    }

    if (viewMode === 'map' && mapRef.current && isOnline) {
      setTimeout(() => {
        mapRef.current.invalidateSize();
      }, 100);
    }

    // Clean up map reference if view changes or offline triggers
    if (!isOnline && mapRef.current) {
      mapRef.current.remove();
      mapRef.current = null;
    }
  }, [viewMode, isOnline]);

  // Markers update and focusing
  useEffect(() => {
    if (mapRef.current && isOnline) {
      // @ts-ignore
      const L = window.L;
      if (!L) return;
      
      // Clear old markers
      Object.values(markersRef.current).forEach((m: any) => m.remove());
      markersRef.current = {};

      if (filteredClinics.length > 0) {
        const bounds: any[] = [];
        filteredClinics.forEach(clinic => {
          const marker = L.marker([clinic.lat, clinic.lng])
            .addTo(mapRef.current)
            .bindPopup(`
              <div class="p-1 min-w-[150px]">
                <h4 class="font-bold text-gray-800">${clinic.name}</h4>
                <p class="text-xs text-blue-600 font-semibold mb-1">${translateType(clinic.type)}</p>
                <p class="text-xs text-gray-600 mb-2">${clinic.location}</p>
                <a href="tel:${clinic.phone.replace(/\s/g, '')}" class="text-xs font-bold text-blue-600 underline">
                  <i class="fas fa-phone-alt"></i> ${isKrio ? 'Kɔl na fon' : 'Call'} ${clinic.phone}
                </a>
              </div>
            `);
          markersRef.current[clinic.id] = marker;
          bounds.push([clinic.lat, clinic.lng]);
        });

        // If we have a selected clinic, focus on it
        if (selectedClinicId && markersRef.current[selectedClinicId]) {
          const target = filteredClinics.find(c => c.id === selectedClinicId);
          if (target) {
            mapRef.current.setView([target.lat, target.lng], 16);
            markersRef.current[selectedClinicId].openPopup();
          }
        } else if (bounds.length > 0) {
          mapRef.current.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
        }
      }
    }
  }, [filteredClinics, viewMode, selectedClinicId, isKrio, isOnline]);

  const handleViewOnMap = (id: string) => {
    if (!isOnline) {
      showToast(isKrio ? "Intanɛt nɔ de fɔ lod di map. Yus list fɔ kɔl." : "Internet connection is required to load interactive maps.");
      return;
    }
    setSelectedClinicId(id);
    setViewMode('map');
  };

  return (
    <div className="flex-1 flex flex-col bg-gray-50 h-full overflow-hidden printable-clinics relative">
      {/* Printable Header - Only visible during print */}
      <div className="print-only hidden mb-8 text-center border-b-2 border-blue-600 pb-6">
        <div className="flex justify-center mb-4">
          <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center text-white text-2xl">
            <i className="fas fa-plus-square"></i>
          </div>
        </div>
        <h1 className="text-3xl font-bold text-gray-800">DoxaCare AI Clinic Directory</h1>
        <p className="text-sm text-blue-700 font-bold uppercase tracking-widest mt-1">Sierra Leone Healthcare Access List</p>
        <div className="flex justify-between mt-4 text-[10px] text-gray-500 uppercase font-semibold">
          <span>Date: {new Date().toLocaleDateString()}</span>
          <span>{filteredClinics.length} Facilities Listed</span>
        </div>
      </div>

      <div className="p-4 md:p-6 pb-2 shrink-0 no-print">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div className="flex items-center space-x-3">
            <div className="text-blue-600 text-2xl">
              <i className="fas fa-map-marked-alt"></i>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-2xl font-bold text-gray-800">
                  {isKrio ? "Find Osptul/Famasi" : "Find Clinics"}
                </h2>
                {isOnline ? (
                  <span className="inline-flex items-center space-x-1 bg-green-50 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-green-200">
                    <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                    <span>ONLINE</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center space-x-1 bg-amber-50 text-amber-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-200">
                    <span className="w-1.5 h-1.5 bg-amber-500 rounded-full"></span>
                    <span>OFFLINE CACHED</span>
                  </span>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar pb-1">
            <div className="flex bg-white rounded-lg border border-gray-200 p-1 shadow-sm shrink-0">
              <button 
                onClick={() => { setViewMode('list'); setSelectedClinicId(null); }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${viewMode === 'list' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}
              >
                <i className="fas fa-list mr-1"></i> {isKrio ? "Lis" : "List"}
              </button>
              <button 
                onClick={() => {
                  if (!isOnline) {
                    showToast(isKrio ? "Map nɔ de load fɔ offline mode" : "Map is not available offline");
                    return;
                  }
                  setViewMode('map');
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${!isOnline ? 'opacity-30 cursor-not-allowed text-gray-400' : viewMode === 'map' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}
                disabled={!isOnline}
              >
                <i className="fas fa-map mr-1"></i> {isKrio ? "Map" : "Map"}
              </button>
            </div>
            
            <button
              onClick={handlePrint}
              disabled={filteredClinics.length === 0}
              className="px-3 py-2 bg-white border border-gray-200 rounded-lg text-xs font-bold text-gray-700 hover:bg-gray-50 active:scale-95 transition-all shadow-sm flex items-center shrink-0 disabled:opacity-50"
            >
              <i className="fas fa-file-pdf text-red-500 mr-2"></i>
              {isKrio ? "Sɛv/Print" : "Save/Print"}
            </button>
          </div>
        </div>
        
        <p className="text-gray-500 text-sm mb-4 leading-relaxed">
          {isKrio 
            ? "Luk fɔ osptul, dokta os, or famasi na di ples we yu de. Yu kin tayp di nem or wetin yu de luk fɔ." 
            : "Search for clinics, hospitals, or pharmacies. You can search by name, type, or service."}
        </p>

        {/* Offline Banner announcement */}
        {!isOnline && (
          <div className="mb-4 p-3 bg-amber-50 border border-amber-100 rounded-2xl flex items-start text-xs text-amber-800 shadow-sm transition-all no-print animate-pulse">
            <i className="fas fa-wifi-slash mt-0.5 mr-2.5 text-amber-500 text-sm shrink-0"></i>
            <div>
              <span className="font-bold">
                {isKrio ? "Yu nɔ de na intanɛt! " : "Poor or no internet connection detected! "}
              </span>
              <span>
                {isKrio 
                  ? "DoxaCare de sho yu di clinic directory we dɔn download and sɛv na yu device local cache fɔ offline access." 
                  : "We're showing clinic directory listings saved on this device so you can find treatments offline."}
              </span>
            </div>
          </div>
        )}

        {/* Saved/Cached Sub tabs filter selection */}
        <div className="flex bg-gray-100 border border-gray-200/50 rounded-2xl p-1 mb-4 shadow-inner no-print gap-1">
          <button
            onClick={() => setFilterSavedOnly(false)}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${!filterSavedOnly ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <i className="fas fa-hospital mr-1.5 text-blue-500"></i>
            {isKrio ? "Sɔ we de na di lis" : "All Facilities"} ({clinics.length})
          </button>
          <button
            onClick={() => setFilterSavedOnly(true)}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center ${filterSavedOnly ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <i className="fas fa-star mr-1.5 text-yellow-500"></i>
            {isKrio ? "Di wan dɛn we a Sɛv" : "My Saved Clinics"}
            {savedClinicIds.length > 0 && (
              <span className="ml-1.5 bg-yellow-100 text-yellow-800 text-[10px] px-1.5 py-0.5 rounded-full font-extrabold shadow-sm">
                {savedClinicIds.length}
              </span>
            )}
          </button>
        </div>

        {/* Search and Filters Container */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Search Bar */}
          <div className="md:col-span-2 flex items-center bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden focus-within:ring-2 focus-within:ring-blue-500 transition-all">
            <div className="pl-4 text-gray-400">
              <i className="fas fa-search"></i>
            </div>
            <input
              type="text"
              value={query}
              onChange={(e) => { setQuery(e.target.value); setSelectedClinicId(null); }}
              placeholder={isKrio ? "Tayp nem or sɔvis (e.g. malaria, bɛlɛ)..." : "Type name or service (e.g. malaria, surgical)..."}
              className="flex-1 bg-transparent px-4 py-4 outline-none text-gray-700 text-sm"
            />
          </div>

          {/* District Selector */}
          <div className="relative">
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full h-full bg-white rounded-2xl border border-gray-200 shadow-sm px-4 py-3 md:py-0 text-sm text-gray-700 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer"
            >
              <option value="all">{isKrio ? "All Distrikt" : "All Districts"}</option>
              {districts.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-gray-400">
              <i className="fas fa-chevron-down"></i>
            </div>
          </div>

          {/* Type Selector */}
          <div className="relative">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full h-full bg-white rounded-2xl border border-gray-200 shadow-sm px-4 py-3 md:py-0 text-sm text-gray-700 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer"
            >
              <option value="all">{isKrio ? "All Ples" : "All Facility Types"}</option>
              {clinicTypes.map(t => (
                <option key={t} value={t}>{translateType(t)}</option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-gray-400">
              <i className="fas fa-chevron-down"></i>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 relative">
        {viewMode === 'list' ? (
          <div className="absolute inset-0 overflow-y-auto px-4 md:px-6 pb-24 space-y-4 printable-list">
            {filteredClinics.length > 0 ? (
              filteredClinics.map((clinic) => (
                <div key={clinic.id} className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow group break-inside-avoid print:shadow-none print:border-gray-300 print:mb-6">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1 mr-2">
                      <div className="flex items-center space-x-2 flex-wrap">
                        <h3 className="font-bold text-gray-800 text-lg print:text-xl">{clinic.name}</h3>
                        <button
                          onClick={() => toggleSaveClinic(clinic.id, clinic.name)}
                          className="p-1 text-yellow-500 hover:text-yellow-600 transition-colors focus:outline-none no-print active:scale-125 hover:scale-110"
                          title={savedClinicIds.includes(clinic.id) ? "Remove from offline list" : "Save for offline list"}
                        >
                          <i className={`${savedClinicIds.includes(clinic.id) ? 'fas fa-star text-yellow-500' : 'far fa-star text-gray-300'} text-lg`} />
                        </button>
                      </div>
                      <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full print:bg-transparent print:border print:border-blue-200 print:text-blue-800 inline-block mt-1">
                        {translateType(clinic.type)}
                      </span>
                    </div>
                    <div className="flex flex-col items-end space-y-1 no-print shrink-0">
                      {clinic.is24Hour && (
                        <span className="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-1 rounded-lg flex items-center">
                          <i className="fas fa-clock mr-1"></i> {isKrio ? "OL DE & NET" : "24-HOUR"}
                        </span>
                      )}
                      {clinic.isAddictionSupport && (
                        <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-1 rounded-lg flex items-center shadow-sm">
                          <i className="fas fa-life-ring mr-1"></i> {isKrio ? "KUSH ƐP" : "ADDICTION SUPPORT"}
                        </span>
                      )}
                    </div>
                  </div>

                  {clinic.description && (
                    <p className="text-gray-500 text-sm mb-4 leading-relaxed line-clamp-2">
                      {clinic.description}
                    </p>
                  )}

                  <div className="space-y-3 mt-4">
                    <div className="flex items-start text-sm text-gray-600">
                      <i className="fas fa-map-marker-alt mt-1 mr-3 text-gray-400 no-print col-span-3 shrink-0"></i>
                      <div className="flex-1">
                        <p className="font-medium print:text-base">{clinic.location}</p>
                        <p className="text-xs opacity-75 print:text-sm">{clinic.district} {isKrio ? "Distrikt" : "District"}</p>
                      </div>
                      <button 
                        onClick={() => handleViewOnMap(clinic.id)}
                        className="text-blue-600 hover:text-blue-800 text-xs font-bold uppercase tracking-wider flex items-center space-x-1 ml-2 no-print shrink-0 mt-1"
                      >
                        <i className="fas fa-location-arrow"></i>
                        <span>{isKrio ? "Luk am na map" : "View on Map"}</span>
                      </button>
                    </div>

                    {/* Responsive Clickable Phone Number */}
                    <a 
                      href={`tel:${clinic.phone.replace(/\s/g, '')}`}
                      className="flex items-center text-sm text-blue-600 font-bold bg-blue-50/50 p-3 rounded-2xl border border-blue-100 hover:bg-blue-100 transition-all active:scale-[0.98] group/phone no-print"
                    >
                      <i className="fas fa-phone-alt mr-3 text-blue-400 group-hover/phone:animate-bounce"></i>
                      <span>{isKrio ? 'Kɔl naw: ' : 'Call Now: '}</span>
                      <span className="ml-1">{clinic.phone}</span>
                    </a>

                    {/* Book Appointment Button */}
                    <button
                      onClick={() => {
                        setBookingClinic(clinic);
                        if (auth.currentUser) {
                          setPatientName(auth.currentUser.displayName || '');
                          setContactPhone('');
                          setBookingDate('');
                          setBookingTime('');
                          setBookingNotes('');
                          setBookingSuccess(null);
                          setBookingError(null);
                        } else {
                          setPatientName('');
                          setContactPhone('');
                          setBookingDate('');
                          setBookingTime('');
                          setBookingNotes('');
                          setBookingSuccess(null);
                          setBookingError(null);
                        }
                      }}
                      className="w-full mt-2 bg-green-600 hover:bg-green-700 text-white font-extrabold text-[11px] py-3 rounded-xl shadow-xs transition active:scale-[0.98] flex items-center justify-center space-x-2 no-print cursor-pointer"
                    >
                      <i className="fas fa-calendar-check text-white"></i>
                      <span>{isKrio ? "Book Appointment na Clinic" : "Book Clinic Appointment"}</span>
                    </button>

                    {/* Print-only phone display */}
                    <div className="hidden print:flex items-center text-sm font-bold p-3 border border-gray-200 rounded-2xl">
                      <span>{isKrio ? 'Kɔl: ' : 'Call: '}</span>
                      <span className="ml-1 text-lg">{clinic.phone}</span>
                      {clinic.is24Hour && <span className="ml-auto text-[10px] uppercase font-bold text-green-700 border border-green-200 px-2 py-1 rounded">24/7 Available</span>}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-20 no-print bg-white rounded-3xl border border-gray-100 p-6 shadow-sm">
                <div className="text-gray-300 text-5xl mb-4">
                  <i className="fas fa-hospital-alt"></i>
                </div>
                <p className="text-gray-500 font-medium">
                  {filterSavedOnly 
                    ? (isKrio ? "Yu nɔ sɛv no mɛdisin ples yet na dis device." : "You haven't saved any clinics on this device yet.")
                    : (isKrio ? "Wi nɔ find di ples we yu de luk fɔ. Try luk fɔ anɔda wan." : "No matching clinics found. Try another search.")
                  }
                </p>
                {filterSavedOnly && (
                  <button
                    onClick={() => setFilterSavedOnly(false)}
                    className="mt-4 px-4 py-2 bg-blue-600 font-bold text-xs text-white rounded-xl shadow hover:bg-blue-700 transition"
                  >
                    {isKrio ? "Broze ɔl mɛdisin ples dɛn" : "Browse All Clinics"}
                  </button>
                )}
              </div>
            )}
          </div>
        ) : (
          isOnline ? (
            <div ref={mapContainerRef} className="w-full h-full z-0 no-print" style={{ minHeight: '300px' }} />
          ) : (
            /* Custom Offline Map mode placeholder visual */
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-gray-50 border border-t border-gray-100 h-full absolute inset-0 z-10 no-print">
              <div className="w-20 h-20 bg-amber-50 text-amber-500 rounded-full flex items-center justify-center text-3xl mb-4 border border-amber-200 shadow-sm animate-pulse">
                <i className="fas fa-wifi-slash"></i>
              </div>
              <h3 className="font-extrabold text-gray-800 text-lg mb-2">
                {isKrio ? "Map nɔ de load fɔ offline" : "Interactive Map Requires Internet"}
              </h3>
              <p className="text-gray-500 text-sm max-w-sm mb-6 leading-relaxed">
                {isKrio 
                  ? "Leaflet mɛps de nid active intanɛt fɔ lod di say dɛn. Bɔti yu kin stil read, filta, ɛn kɔl na di list fɔ and sɛv dɛn osptul offline!" 
                  : "We cannot load openstreet maps without internet. Use style listings and phone numbers cached locally!"}
              </p>
              <button 
                onClick={() => setViewMode('list')} 
                className="px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl shadow-md hover:bg-blue-700 transition active:scale-95"
              >
                <i className="fas fa-list mr-2"></i>
                {isKrio ? "Go na di Lis" : "Switch to List View"}
              </button>
            </div>
          )
        )}
      </div>

      {/* Footer for Print Only */}
      <div className="print-only hidden mt-12 pt-6 border-t border-gray-200 text-center">
        <p className="text-[10px] text-gray-500 leading-relaxed max-w-lg mx-auto">
          <strong>Important Notice:</strong> This list of health facilities was generated by DoxaCare AI. Information such as hours of operation and phone numbers may change. In the event of a critical emergency, please proceed directly to the nearest hospital or <strong>Call 117</strong>.
          <br /><br />
          &copy; {new Date().getFullYear()} DoxaCare AI - Sierra Leone Health Assistant
        </p>
      </div>

      {/* Clinic Booking Form Modal Overlay */}
      {bookingClinic && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print">
          <div className="w-full max-w-md bg-white rounded-[32px] shadow-2xl border border-gray-100 p-6 md:p-8 animate-in fade-in zoom-in-95 duration-250 relative overflow-y-auto max-h-[90vh]">
            
            <button 
              onClick={() => setBookingClinic(null)}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-500 flex items-center justify-center transition"
            >
              <i className="fas fa-times"></i>
            </button>

            {!auth.currentUser ? (
              <div className="text-center py-6">
                <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center text-xl mx-auto mb-4">
                  <i className="fas fa-lock"></i>
                </div>
                <h3 className="text-lg font-black text-gray-800 leading-none">
                  {isKrio ? "Log in fɔ book Clinic" : "Sign In Required"}
                </h3>
                <p className="text-sm text-gray-400 font-semibold mt-3 leading-relaxed">
                  {isKrio 
                    ? "Yu nid fɔ lig-in fɔ book and secure apɔyntmɛnts wit di clinics inside Sierra Leone." 
                    : "You must be signed in to book or schedule clinical consultations secure in the cloud."}
                </p>
                <div className="mt-6 flex space-x-3">
                  <button
                    onClick={() => { setBookingClinic(null); }}
                    className="flex-1 py-3 text-xs font-bold bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-2xl transition"
                  >
                    {isKrio ? "Kose" : "Cancel"}
                  </button>
                  <button
                    onClick={() => {
                      setBookingClinic(null);
                      if (onLoginRedirect) onLoginRedirect();
                    }}
                    className="flex-1 py-3 text-xs font-black bg-green-600 hover:bg-green-700 text-white rounded-2xl shadow-md transition"
                  >
                    {isKrio ? "Login Naw" : "Sign In Now"}
                  </button>
                </div>
              </div>
            ) : bookingSuccess ? (
              <div className="text-center py-6">
                <div className="w-16 h-16 bg-green-50 text-green-600 rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
                  <i className="fas fa-check-circle"></i>
                </div>
                <h3 className="text-xl font-black text-gray-800 leading-none">
                  {isKrio ? "Apɔyntmɛnt Sent!" : "Booking Request Sent!"}
                </h3>
                <p className="text-xs text-green-600 font-bold uppercase tracking-wider mt-2 bg-green-50 rounded px-2.5 py-1 inline-block">
                  Status: PENDING CLINICAL VERIFICATION
                </p>
                <div className="mt-4 p-4 bg-gray-50 rounded-2xl text-left text-xs text-gray-600 space-y-1.5 border border-gray-100">
                  <p><strong>{isKrio ? "Medisin Ples" : "Health Clinic"}:</strong> {bookingClinic.name}</p>
                  <p><strong>{isKrio ? "Patient Name" : "Patient Name"}:</strong> {bookingSuccess.patientName}</p>
                  <p><strong>{isKrio ? "Fon nɔbɔ" : "Contact Phone"}:</strong> {bookingSuccess.contactPhone}</p>
                  <p><strong>{isKrio ? "Date/Tɛm" : "Date / Time"}:</strong> {bookingSuccess.date} @ {bookingSuccess.time}</p>
                </div>
                <p className="text-xs text-gray-400 mt-4 leading-relaxed">
                  {isKrio 
                    ? "DoxaCare dɔn transmit yu list fɔ di Clinic. Dɛn go kɔl yu fɔ confirm." 
                    : "The clinic has been notified. They will call you directly at your contact phone number to finalize your slot."}
                </p>
                <button
                  onClick={() => setBookingClinic(null)}
                  className="w-full mt-6 py-3.5 bg-green-600 hover:bg-green-700 text-white font-extrabold text-sm rounded-2xl shadow transition"
                >
                  {isKrio ? "Close am" : "Done"}
                </button>
              </div>
            ) : (
              <form onSubmit={handleBookSubmit} className="space-y-4">
                <div className="mb-4">
                  <span className="inline-block bg-blue-50 text-blue-800 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full mb-1">
                    {translateType(bookingClinic.type)}
                  </span>
                  <h3 className="text-lg font-black text-gray-800 leading-tight">{bookingClinic.name}</h3>
                  <p className="text-[11px] text-gray-400 mt-1">{bookingClinic.location}</p>
                </div>

                {bookingError && (
                  <div className="p-3 bg-red-50 border border-red-100 text-red-800 text-xs font-semibold rounded-2xl flex items-start space-x-2">
                    <i className="fas fa-exclamation-circle mt-0.5 shrink-0"></i>
                    <span>{bookingError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-wider pl-1 mb-1">
                    {isKrio ? "Pasin E Name" : "Patient Name *"}
                  </label>
                  <input
                    type="text"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    required
                    placeholder={isKrio ? "Full Name fɔ Patient" : "Full name of patient"}
                    className="w-full bg-gray-50 border border-gray-200 focus:ring-1 focus:ring-green-500 focus:border-green-500 rounded-2xl px-4 py-3 text-sm focus:outline-none transition-all"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-wider pl-1 mb-1">
                    {isKrio ? "Sierra Leone Fon Nɔbɔ *" : "Sierra Leone Contact Phone *"}
                  </label>
                  <input
                    type="tel"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    required
                    placeholder="e.g. +232 76 123456"
                    className="w-full bg-gray-50 border border-gray-200 focus:ring-1 focus:ring-green-500 focus:border-green-500 rounded-2xl px-4 py-3 text-sm focus:outline-none transition-all"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-wider pl-1 mb-1">
                      {isKrio ? "Sɛlɛkt Date *" : "Preferred Date *"}
                    </label>
                    <input
                      type="date"
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      required
                      min={new Date().toISOString().split('T')[0]}
                      className="w-full bg-gray-50 border border-gray-200 focus:ring-1 focus:ring-green-500 focus:border-green-500 rounded-2xl px-4 py-3 text-sm focus:outline-none transition-all cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-wider pl-1 mb-1">
                      {isKrio ? "Sɛlɛkt Tɛm *" : "Preferred Slot *"}
                    </label>
                    <select
                      value={bookingTime}
                      onChange={(e) => setBookingTime(e.target.value)}
                      required
                      className="w-full bg-gray-50 border border-gray-200 focus:ring-1 focus:ring-green-500 focus:border-green-500 rounded-2xl px-4 py-3 text-sm focus:outline-none transition-all cursor-pointer text-gray-600 font-bold"
                    >
                      <option value="">{isKrio ? "--Tɛm--" : "--Select--"}</option>
                      <option value="Morning (09:00 - 12:00)">{isKrio ? "Mɔnin (09:00 - 12:00)" : "Morning (09:00 - 12:00)"}</option>
                      <option value="Afternoon (12:00 - 15:00)">{isKrio ? "Aftanun (12:00 - 15:00)" : "Afternoon (12:00 - 15:00)"}</option>
                      <option value="Late Afternoon (15:00 - 17:00)">{isKrio ? "Let Aftanun (15:00 - 17:00)" : "Late Afternoon (15:00 - 17:00)"}</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-wider pl-1 mb-1">
                    {isKrio ? "Detel (Optional)" : "Optional Notes / Symptoms"}
                  </label>
                  <textarea
                    value={bookingNotes}
                    onChange={(e) => setBookingNotes(e.target.value)}
                    rows={2}
                    placeholder={isKrio ? "Mek wi no sɔm tin..." : "Brief notes for attending clinical nurse..."}
                    className="w-full bg-gray-50 border border-gray-200 focus:ring-1 focus:ring-green-500 focus:border-green-500 rounded-2xl px-4 py-3 text-sm focus:outline-none transition-all resize-none"
                  />
                </div>

                <div className="pt-2 flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setBookingClinic(null)}
                    className="flex-1 py-3 text-xs font-bold bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-2xl transition"
                  >
                    {isKrio ? "Kose" : "Cancel"}
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingBooking}
                    className="flex-1 py-3 bg-green-600 hover:bg-green-700 text-white font-extrabold text-xs rounded-2xl shadow-md transition flex items-center justify-center space-x-2"
                  >
                    {isSubmittingBooking ? (
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <>
                        <i className="fas fa-paper-plane text-xs"></i>
                        <span>{isKrio ? "Sɛnd Book" : "Submit Booking"}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

      {/* Dynamic Toast feedback on saving / bookmarking */}
      {toast && (
        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 bg-gray-900/90 backdrop-blur-sm text-white px-5 py-3 rounded-2xl text-xs font-semibold shadow-lg z-50 flex items-center space-x-2 animate-bounce border border-gray-800">
          <i className="fas fa-star text-yellow-400 animate-spin"></i>
          <span>{toast}</span>
        </div>
      )}

      <style>{`
        .leaflet-container {
          width: 100%;
          height: 100%;
        }
        .leaflet-popup-content-wrapper {
          border-radius: 1rem;
          padding: 0.5rem;
          box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }
        .leaflet-popup-tip {
          background: white;
        }

        @media print {
          /* Force exact colors */
          * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          /* Reset layout */
          body > * {
            display: none !important;
          }

          .printable-clinics, .printable-clinics * {
            display: block !important;
          }

          .printable-clinics {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            height: auto !important;
            margin: 0 !important;
            padding: 10mm !important;
            background: white !important;
            overflow: visible !important;
          }

          .printable-list {
            position: relative !important;
            display: block !important;
            padding: 0 !important;
            overflow: visible !important;
          }

          .no-print {
            display: none !important;
          }

          .print-only {
            display: block !important;
          }

          .break-inside-avoid {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }

          /* Clear interactive elements for print */
          button, input, select, .leaflet-container {
            display: none !important;
          }

          @page {
            size: A4;
            margin: 10mm;
          }
        }
      `}</style>
    </div>
  );
};

export default ClinicView;
