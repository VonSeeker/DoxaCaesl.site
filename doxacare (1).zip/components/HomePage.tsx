
import React from 'react';
import { NavMenuOption, Language } from '../types';
import { DOXA_AI_NAV_MENU } from '../constants';
import BrandIcon from './BrandIcon';

interface HomePageProps {
  onSelectOption: (option: NavMenuOption) => void;
  onViewCasebook: () => void;
  language: Language;
}

const HomePage: React.FC<HomePageProps> = ({ onSelectOption, onViewCasebook, language }) => {
  const isKrio = language === Language.KRIO;

  return (
    <div className="flex-1 overflow-y-auto bg-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-green-600 to-green-700 text-white px-6 py-10 rounded-b-[40px] shadow-lg mb-6 relative overflow-hidden">
        {/* Decorative Background Icon */}
        <div className="absolute -right-8 -top-8 opacity-10 rotate-12">
          <BrandIcon size={200} color="white" />
        </div>

        <div className="relative z-10">
          <div className="flex items-center space-x-4 mb-6">
            <div className="bg-white/20 p-2 rounded-2xl backdrop-blur-sm border border-white/10 shadow-xl">
              <BrandIcon className="w-12 h-12" color="white" />
            </div>
            <div>
              <h2 className="text-3xl font-extrabold leading-tight">
                {isKrio ? "Kushɛ! Aw yu du tide?" : "DoxaCare AI"}
              </h2>
              <p className="text-green-150 text-[10px] font-black uppercase tracking-widest mt-1">AI Middle-Layer fɔ Sierra Leone</p>
            </div>
          </div>
          
          <p className="text-green-50 opacity-95 text-xs md:text-sm mb-6 max-w-sm font-bold leading-relaxed">
            {isKrio 
              ? "Wi de bring global medical research na Sierra Leone wit AI middle-layer fɔ help yu check symptom and find clinic sese." 
              : "DoxaCare acts as an AI middle-layer, bringing precise global medical research to families and clinics across Sierra Leone."}
          </p>
          
          <button 
            onClick={() => onSelectOption({ id: '0', label: 'Start Chat', krioLabel: 'Bigan tɔk', icon: 'fa-comments' })}
            className="bg-white text-green-700 px-6 py-3 rounded-2xl text-xs font-black shadow-md flex items-center space-x-2 transition-transform hover:scale-102 active:scale-95"
          >
            <i className="fas fa-comment-dots"></i>
            <span>{isKrio ? "Tɔk to Doxa AI" : "Chat with Doxa AI"}</span>
          </button>
        </div>
      </div>

      {/* Strategic Mission Band */}
      <div className="px-6 mb-6">
        <div className="bg-slate-900 text-white rounded-3xl p-5 relative overflow-hidden border border-slate-800 shadow-xl">
          <div className="absolute right-0 bottom-0 translate-x-1/4 translate-y-1/4 w-32 h-32 bg-green-500/10 rounded-full blur-xl"></div>
          <p className="text-[9px] text-green-400 font-black uppercase tracking-widest mb-1.5 flex items-center space-x-1.5">
            <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-ping"></span>
            <span>DI DOXACARE MISSION STRATEGY</span>
          </p>
          <h3 className="text-xs font-black tracking-tight leading-snug mb-1.5">
            {isKrio 
              ? "AI middle-layer wey de bring global medical research na Sierra Leone" 
              : "AI middle-layer bringing global medical research to Sierra Leone"}
          </h3>
          <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">
            {isKrio 
              ? "DoxaCare de bridge we gap fɔ bring proper health na Sierra Leone. Wi de use precise global clinical research (WHO/Lancet/CDC) fɔ check fɛvɛ, malaria, and maternal care."
              : "DoxaCare establishes a vital clinical middle-layer, bringing professional global medical research (WHO, Lancet, CDC) to patients in Sierra Leone. We empower families to communicate precise symptoms clearly to local clinic nurses and doctors."}
          </p>
        </div>
      </div>


      {/* Patient Case Vault Entry Banner */}
      <div className="px-6 mb-6">
        <button
          onClick={onViewCasebook}
          className="w-full bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-850 text-white p-4 rounded-3xl shadow-md hover:shadow-lg transition active:scale-98 text-left flex items-center justify-between"
        >
          <div className="flex items-center space-x-3.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center text-white text-lg">
              <i className="fas fa-book-medical"></i>
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-200 block">
                {isKrio ? "Mi Saved Case Book" : "My Patient Case Book"}
              </span>
              <span className="text-xs font-bold leading-tight block mt-0.5">
                {isKrio ? "Show yu save briefs to doctors offline" : "Present clinical briefings to doctors offline"}
              </span>
            </div>
          </div>
          <div className="text-white/60">
            <i className="fas fa-chevron-right"></i>
          </div>
        </button>
      </div>

      {/* Services Grid */}
      <div className="px-6 pb-10">
        <h3 className="text-gray-500 uppercase text-[10px] font-bold tracking-widest mb-4">
          {isKrio ? "Wetin wi kin du?" : "Our Core Services"}
        </h3>
        <div className="grid grid-cols-2 gap-4">
          {DOXA_AI_NAV_MENU.map((option) => (
            <button
              key={option.id}
              onClick={() => onSelectOption(option)}
              className={`flex flex-col items-center justify-center p-5 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all active:scale-95 text-center ${
                option.id === '6' ? 'bg-red-50 border-red-100' : 'bg-white'
              }`}
            >
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-3 ${
                option.id === '6' ? 'bg-red-500 text-white' : 'bg-green-100 text-green-600'
              }`}>
                <i className={`fas ${option.icon} text-xl`}></i>
              </div>
              <span className={`text-xs font-bold leading-tight ${option.id === '6' ? 'text-red-700' : 'text-gray-700'}`}>
                {isKrio ? option.krioLabel : option.label}
              </span>
            </button>
          ))}
        </div>

        {/* Info Card */}
        <div className="mt-8 bg-blue-50 border border-blue-100 rounded-3xl p-5 flex items-start space-x-4">
          <div className="text-blue-500 mt-1 text-xl">
            <i className="fas fa-shield-alt"></i>
          </div>
          <div>
            <h4 className="text-sm font-bold text-blue-900 mb-1">
              {isKrio ? "Sese ɛn Fri" : "Private & Secure"}
            </h4>
            <p className="text-xs text-blue-800 opacity-80 leading-relaxed">
              {isKrio 
                ? "Yu nɔ nid fɔ register. Wi nɔ de ask fɔ yu nem or yu fon namba. Evriting sese."
                : "No registration required. We don't ask for your name or phone number. Your health data stays private."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
