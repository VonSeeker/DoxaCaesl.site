import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language } from '../types';
import { auth } from '../firebase';
import { fetchUserBookings, cancelBookingRequest, FirebaseBooking } from '../firebaseService';

interface BookingsViewProps {
  language: Language;
  onBackToClinics: () => void;
  onLoginRedirect: () => void;
}

const BookingsView: React.FC<BookingsViewProps> = ({ language, onBackToClinics, onLoginRedirect }) => {
  const isKrio = language === Language.KRIO;
  const [bookings, setBookings] = useState<FirebaseBooking[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  const loadBookings = async () => {
    if (!auth.currentUser) {
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const data = await fetchUserBookings();
      setBookings(data);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(isKrio ? "Eror lod boking list. Check connection." : "Failed to load booking history. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, []);

  const handleCancel = async (id: string) => {
    setActionLoadingId(id);
    setErrorMessage(null);
    try {
      await cancelBookingRequest(id);
      // Optimistic state sync
      setBookings(prev => prev.map(bk => bk.id === id ? { ...bk, status: 'cancelled' } : bk));
    } catch (err: any) {
      console.error(err);
      setErrorMessage(isKrio ? "We no able cancel am fɔ dis time. Try again." : "Could not cancel appointment. Please check connection.");
    } finally {
      setActionLoadingId(null);
    }
  };

  if (!auth.currentUser) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-50 p-6 text-center">
        <div className="w-16 h-16 bg-green-50 text-green-600 rounded-3xl flex items-center justify-center text-2xl mb-4 shadow-inner">
          <i className="fas fa-lock"></i>
        </div>
        <h3 className="text-xl font-black text-gray-800 leading-none">
          {isKrio ? "Sign In fɔ view Bookings" : "Sign In Required"}
        </h3>
        <p className="text-sm text-gray-400 font-bold uppercase tracking-wider mt-2">
          {isKrio ? "Kriet account or sign-in fɔ see booking records" : "Personal Appointments Dashboard"}
        </p>
        <p className="text-xs text-gray-400 max-w-xs mt-3 leading-relaxed">
          {isKrio 
            ? "Yu gɛt fɔ login fɔ join di cloud and see all clinic bookings wey yu do." 
            : "Sign in to access secure history, track medical reviews, and cancel bookings."}
        </p>
        <button
          onClick={onLoginRedirect}
          className="mt-6 px-6 py-3.5 bg-green-600 hover:bg-green-700 text-white font-extrabold text-sm rounded-2xl shadow-md transition active:scale-95 cursor-pointer"
        >
          {isKrio ? "Sign In Now" : "Sign In to DoxaCare"}
        </button>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-hidden">
      
      {/* Title block */}
      <div className="bg-white border-b border-gray-100 px-6 py-5 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-green-50 text-green-600 flex items-center justify-center text-lg">
              <i className="fas fa-calendar-alt"></i>
            </div>
            <div>
              <h2 className="text-xl font-black text-gray-800 tracking-tight leading-none">
                {isKrio ? "A Boking Schedul" : "My Appointments"}
              </h2>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1.5">
                {isKrio ? "Track pending clinic visits" : "Track Clinical Reservations & History"}
              </p>
            </div>
          </div>
          <button
            onClick={onBackToClinics}
            className="px-4 py-2 bg-gray-150 hover:bg-gray-100 text-gray-600 font-bold text-xs rounded-xl flex items-center space-x-1 transition cursor-pointer"
          >
            <i className="fas fa-plus"></i>
            <span>{isKrio ? "New Book" : "Book New"}</span>
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        
        {errorMessage && (
          <div className="p-4 bg-red-50 border border-red-100 text-red-800 text-xs font-semibold rounded-2xl flex items-start space-x-2">
            <i className="fas fa-exclamation-circle mt-0.5 shrink-0"></i>
            <span>{errorMessage}</span>
          </div>
        )}

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-green-600 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-xs text-gray-500 font-semibold">{isKrio ? "Wi dɛn load bookings..." : "Syncing appointments database..."}</p>
          </div>
        ) : bookings.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-3xl border border-gray-100 p-6 shadow-sm max-w-md mx-auto">
            <div className="w-16 h-16 bg-gray-50 text-gray-300 rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <i className="fas fa-calendar-times"></i>
            </div>
            <h4 className="font-extrabold text-gray-800 text-base">{isKrio ? "No appointments yet!" : "No Appointments Found"}</h4>
            <p className="text-xs text-gray-400 mt-2 leading-relaxed">
              {isKrio 
                ? "Yu nɔ book any clinic apɔyntmɛnt yet. Gɔ na clinic view fɔ schedule slot." 
                : "You have not scheduled any appointments yet. Head to the Clinic Finder to request slots."}
            </p>
            <button
              onClick={onBackToClinics}
              className="mt-5 px-5 py-3 bg-green-600 hover:bg-green-700 text-white font-extrabold text-xs rounded-2xl shadow transition"
            >
              {isKrio ? "Fine Clinik Now" : "Find Clinics & Hospitals"}
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <AnimatePresence>
              {bookings.map((booking) => {
                const isPending = booking.status === 'pending';
                const isConfirmed = booking.status === 'confirmed';
                const isCancelled = booking.status === 'cancelled';

                return (
                  <motion.div
                    key={booking.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="bg-white rounded-3xl p-5 border border-gray-100 shadow-sm relative flex flex-col md:flex-row md:items-center justify-between gap-5 hover:border-gray-200 transition-all"
                  >
                    <div className="space-y-3 flex-1">
                      <div className="flex items-center space-x-2.5 flex-wrap">
                        <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-full border ${
                          isConfirmed 
                            ? 'bg-green-50 text-green-700 border-green-200' 
                            : isCancelled 
                            ? 'bg-red-50 text-red-700 border-red-200' 
                            : 'bg-amber-50 text-amber-700 border-amber-200'
                        }`}>
                          {booking.status}
                        </span>
                        <span className="text-[10px] text-gray-400 font-bold">
                          Booked on: {new Date(booking.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      <div>
                        <h4 className="font-black text-gray-800 text-base leading-none">
                          {booking.clinicName}
                        </h4>
                        <p className="text-xs font-semibold text-gray-500 mt-2">
                          Patient Name: <span className="text-gray-800 font-extrabold">{booking.patientName}</span>
                        </p>
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center gap-1.5 sm:gap-4 text-xs font-semibold text-gray-500">
                        <div className="flex items-center space-x-1.5">
                          <i className="far fa-calendar text-gray-400"></i>
                          <span>Date: <strong className="text-gray-700 font-extrabold">{booking.date}</strong></span>
                        </div>
                        <div className="flex items-center space-x-1.5">
                          <i className="far fa-clock text-gray-400"></i>
                          <span>Slot: <strong className="text-gray-700 font-extrabold">{booking.time}</strong></span>
                        </div>
                      </div>

                      {booking.notes && (
                        <p className="text-xs text-gray-400 bg-gray-50/50 p-2.5 border border-gray-100 rounded-xl leading-relaxed">
                          <strong>Note:</strong> {booking.notes}
                        </p>
                      )}
                    </div>

                    <div className="flex md:flex-col justify-between md:justify-center items-end gap-3 border-t md:border-t-0 border-gray-100 pt-3 md:pt-0 shrink-0">
                      <a
                        href={`tel:${booking.contactPhone}`}
                        className="text-xs font-extrabold bg-blue-50 hover:bg-blue-100/70 border border-blue-100 text-blue-800 px-3 py-2 rounded-xl flex items-center space-x-1"
                        title="Attending Phone Number"
                      >
                        <i className="fas fa-phone-alt text-[10px]"></i>
                        <span>{booking.contactPhone}</span>
                      </a>

                      {isPending && (
                        <button
                          onClick={() => handleCancel(booking.id)}
                          disabled={actionLoadingId === booking.id}
                          className="text-xs font-black bg-red-50 hover:bg-red-100 border border-red-100 text-red-600 px-3.5 py-2 rounded-xl flex items-center space-x-1.5 transition active:scale-95 disabled:opacity-50 cursor-pointer"
                        >
                          {actionLoadingId === booking.id ? (
                            <div className="w-3.5 h-3.5 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                          ) : (
                            <>
                              <i className="fas fa-ban text-[10px]"></i>
                              <span>{isKrio ? "Cancel am" : "Cancel"}</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}

      </div>
    </div>
  );
};

export default BookingsView;
