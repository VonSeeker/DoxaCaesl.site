import React, { useState, useEffect } from 'react';
import { HealthAnalysis, Language, SavedCase } from '../types';
import { generateDoctorBrief } from '../geminiService';

interface ClinicalBriefCardProps {
  analysis: HealthAnalysis;
  topic: string;
  language: Language;
  onSaveSuccess?: () => void;
}

const ClinicalBriefCard: React.FC<ClinicalBriefCardProps> = ({ 
  analysis, 
  topic, 
  language,
  onSaveSuccess
}) => {
  const isKrio = language === Language.KRIO;

  // Form Inputs for Clinical Brief custom synthesis
  const [timeline, setTimeline] = useState<string>('3-5 days');
  const [isPregnant, setIsPregnant] = useState<boolean>(false);
  const [selectedSevere, setSelectedSevere] = useState<string[]>([]);
  
  // Loaded Brief Result State
  const [loadingBrief, setLoadingBrief] = useState<boolean>(false);
  const [briefResult, setBriefResult] = useState<{
    clinicalTriage: 'RED' | 'YELLOW' | 'GREEN';
    labDiagnosticTests: string[];
    researchGuidelineSummary: string;
    suggestedDoctorQuestions: string[];
  } | null>(null);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Common severe flags for triage checking
  const severeOptions = [
    { value: 'cannot_drink', label: 'Cannot drink or breastfeed', krio: 'Nɔ fit drink waata or breastfeed' },
    { value: 'convulsions', label: 'Convulsions/seizures/fits', krio: 'Di body de shake/convulsion' },
    { value: 'difficulty_breathing', label: 'Difficulty breathing', krio: 'Taya-breathe or hard fɔ pull wind' },
    { value: 'severe_lethargy', label: 'Extremely weak/unconscious', krio: 'Body weak lala or fɛnt' },
    { value: 'yellow_eyes', label: 'Yellow eyes/ jaundice', krio: 'Yɛlo-fiva or yɛlo yay' },
    { value: 'severe_bleeding', label: 'Unexpected bleeding', krio: 'Blɔd de pull' }
  ];

  const handleSevereToggle = (value: string) => {
    setSelectedSevere(prev => 
      prev.includes(value) ? prev.filter(x => x !== value) : [...prev, value]
    );
  };

  const handleGenerateBrief = async () => {
    setLoadingBrief(true);
    setBriefResult(null);

    const conditionNames = analysis.conditions.map(c => c.name);
    const symptomsList = selectedSevere.map(s => {
      const found = severeOptions.find(o => o.value === s);
      return found ? found.label : s;
    });

    try {
      const briefData = await generateDoctorBrief(
        topic || "General Symptoms",
        conditionNames,
        timeline,
        symptomsList,
        isPregnant,
        isKrio ? "Krio and English" : "English"
      );
      
      setBriefResult(briefData);
    } catch (e) {
      console.error("Clinical Brief Generation Failed", e);
      // Fallback generator in case of network issues
      const isRed = selectedSevere.length > 0 || analysis.conditions.some(c => c.emergencySigns.length > 0);
      setBriefResult({
        clinicalTriage: isRed ? 'RED' : 'YELLOW',
        labDiagnosticTests: [
          "Malaria Rapid Diagnostic Test (mRDT)",
          "Full Blood Count (FBC)",
          "Widal / Typhoid Screen"
        ],
        researchGuidelineSummary: "WHO Standard Fever Assessment Guideline: Early diagnosis of febrile illness is essential to distinguish between malaria, lassa fever, and general sepsis. Delayed treatment increases mortality.",
        suggestedDoctorQuestions: [
          "Do I need a malaria rapid diagnostic test (RDT) today?",
          "Are there local outbreak warnings for Lassa fever in my district?",
          "How long should I wait before my symptoms warrant coming back?"
        ]
      });
    }
    setLoadingBrief(false);
  };

  const handleSaveToCasebook = () => {
    if (!briefResult) return;

    try {
      const savedCasesRaw = localStorage.getItem('doxacare_saved_cases');
      let currentCases: SavedCase[] = [];
      if (savedCasesRaw) {
        currentCases = JSON.parse(savedCasesRaw);
      }

      const severeSymptomsText = selectedSevere.map(s => {
        const found = severeOptions.find(o => o.value === s);
        return found ? (isKrio ? found.krio : found.label) : s;
      });

      const newCase: SavedCase = {
        id: Date.now().toString(),
        topic: topic || "Health Symptom Assessment",
        conditions: analysis.conditions,
        generalAdvice: analysis.generalAdvice,
        patientDetails: {
          timeline,
          severeSymptoms: severeSymptomsText,
          isPregnant
        },
        clinicalTriage: briefResult.clinicalTriage,
        labDiagnosticTests: briefResult.labDiagnosticTests,
        researchGuidelineSummary: briefResult.researchGuidelineSummary,
        suggestedDoctorQuestions: briefResult.suggestedDoctorQuestions,
        timestamp: new Date().toISOString()
      };

      currentCases.unshift(newCase);
      localStorage.setItem('doxacare_saved_cases', JSON.stringify(currentCases));

      setToastMessage(isKrio ? "Saved na yu casebook! Yu kin view am offline." : "Saved to your Case Book! You can view it offline anytime.");
      if (onSaveSuccess) onSaveSuccess();
      
      setTimeout(() => setToastMessage(null), 3000);
    } catch (err) {
      console.error("Error saving clinic brief", err);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-[32px] border border-gray-100 shadow-xl overflow-hidden p-6 md:p-8 relative no-print mb-8">
      
      {/* Decorative Branding */}
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
          <i className="fas fa-file-invoice-dollar text-lg"></i>
        </div>
        <div>
          <h3 className="text-lg font-black text-gray-800 leading-tight">
            {isKrio ? "Gɛt Osptul Drɔgbrief" : "Generate Doctor Clinical Brief"}
          </h3>
          <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">
            {isKrio ? "SERVE AS THE MIDDLE-MAN FOR PROPER TRIAGE & DIAGNOSIS" : "Evidence-Based Patient Referral Assistant"}
          </p>
        </div>
      </div>

      <p className="text-gray-500 text-sm mb-6 leading-relaxed">
        {isKrio 
          ? "Dis AI de turn yu symptoms to clear professional clinical brief wey yu kin take present to any nurse/dokta or pharmacist na Sierra Leone fɔ correct medical diagnostic testing."
          : "Translate your symptom analysis into a professional clinical briefing report. Take this detailed page to any doctor, clinical nurse, or pharmacist to protect your diagnostic correctness."}
      </p>

      {/* Inputs Form */}
      {!briefResult && !loadingBrief && (
        <div className="space-y-5 border-t border-gray-100 pt-5">
          {/* Timeline */}
          <div>
            <label className="block text-xs font-black text-gray-400 uppercase mb-2">
              {isKrio ? "Symptom Timeline (Aw long e dɔn de?):" : "Symptom Timeline (How long has this been occurring?):"}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {['Under 48 hours', '3-5 days', 'Over 1 week'].map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTimeline(t)}
                  className={`py-3 rounded-2xl text-xs font-bold border transition-all ${
                    timeline === t 
                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm' 
                      : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Maternal Pregnancy status */}
          <div className="bg-pink-50/50 border border-pink-100 p-4 rounded-2xl">
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={isPregnant}
                onChange={(e) => setIsPregnant(e.target.checked)}
                className="w-5 h-5 accent-pink-600 rounded bg-white"
              />
              <div>
                <span className="text-sm font-bold text-pink-900 block">
                  {isKrio ? "Di patient gɛt bɛlɛ / dɔn bɔn pikin?" : "Patient is pregnant / maternal nursing?"}
                </span>
                <span className="text-[10px] text-pink-700 block">
                  {isKrio ? "Sɛlɛkt dis fɔ strictly apply Mama ɛn Pikin WHO guidelines" : "Tick this to enforce strict maternal obstetric warning standards"}
                </span>
              </div>
            </label>
          </div>

          {/* Severe Red Flags indicators */}
          <div>
            <label className="block text-xs font-black text-gray-400 uppercase mb-2">
              {isKrio ? "Check if yu gɛt any warning signs ya:" : "Select any warning signs present:"}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {severeOptions.map(opt => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => handleSevereToggle(opt.value)}
                  className={`p-3 rounded-2xl border text-left text-xs font-semibold flex items-center space-x-3 transition-all ${
                    selectedSevere.includes(opt.value)
                      ? 'bg-red-50 border-red-300 text-red-900 shadow-sm'
                      : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <i className={`fas ${selectedSevere.includes(opt.value) ? 'fa-check-circle text-red-600' : 'fa-circle text-gray-300'}`}></i>
                  <span>{isKrio ? opt.krio : opt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Action Trigger Button */}
          <button
            onClick={handleGenerateBrief}
            className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg hover:shadow-xl active:scale-95 transition-all text-sm flex items-center justify-center space-x-2"
          >
            <i className="fas fa-stethoscope"></i>
            <span>{isKrio ? "Synthesize Doctor Clinical Brief" : "Generate Doctor Clinical Brief"}</span>
          </button>
        </div>
      )}

      {/* Loading animation state */}
      {loadingBrief && (
        <div className="py-12 text-center flex flex-col items-center justify-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-blue-800 font-extrabold text-sm uppercase tracking-wider animate-pulse">
            {isKrio ? "Sistem de analyze precise research data..." : "Synthesizing exact research brief..."}
          </p>
          <p className="text-gray-400 text-xs mt-1">Applying WHO, NPHA epidemiological frameworks</p>
        </div>
      )}

      {/* Brief Synthesis Result */}
      {briefResult && (
        <div className="space-y-6 border-t border-gray-100 pt-5">
          
          {/* Triage indicator */}
          <div className={`p-5 rounded-3xl flex items-center space-x-4 border ${
            briefResult.clinicalTriage === 'RED' 
              ? 'bg-red-50 border-red-100 text-red-800' 
              : briefResult.clinicalTriage === 'YELLOW'
                ? 'bg-amber-50 border-amber-100 text-amber-800'
                : 'bg-green-50 border-green-100 text-green-800'
          }`}>
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white text-xl shadow-md ${
              briefResult.clinicalTriage === 'RED' 
                ? 'bg-red-600 animate-pulse' 
                : briefResult.clinicalTriage === 'YELLOW'
                  ? 'bg-amber-500'
                  : 'bg-green-600'
            }`}>
              <i className="fas fa-heartbeat"></i>
            </div>
            <div className="flex-1">
              <span className="text-[10px] uppercase tracking-widest font-extrabold opacity-75">Triage Severity Alert</span>
              <h4 className="text-lg font-black leading-none">
                {briefResult.clinicalTriage === 'RED' 
                  ? (isKrio ? 'EMERGENCY - RED ALERT' : 'EMERGENCY - RED SEVERITY')
                  : briefResult.clinicalTriage === 'YELLOW'
                    ? (isKrio ? 'MODERATE CLINICAL VALUE - YELLOW ALERT' : 'CLINICAL REVIEW - YELLOW SEVERITY')
                    : (isKrio ? 'WELLNESS WATCH - GREEN' : 'WELLNESS MONITORING - GREEN')}
              </h4>
              <p className="text-xs font-semibold mt-1">
                {briefResult.clinicalTriage === 'RED' 
                  ? (isKrio ? 'Immediate referral needed. Go to nearby district hospital or call 117!' : 'Standard protocol triggers immediate regional hospital presentation. Call 117.')
                  : briefResult.clinicalTriage === 'YELLOW'
                    ? (isKrio ? 'Go check na Community Health Centre (CHC) fɔ dynamic testing within 24 hours.' : 'Schedule outpatient counseling/examination at nearest Community Health Post or clinic.')
                    : (isKrio ? 'Keep eye on symptoms. Do self-care and re-evaluate if fever continues.' : 'Symptom level indicates general healthcare or self-monitoring. Stay hydrated.')}
              </p>
            </div>
          </div>

          {/* Sierra Leone Diagnostic Test panel */}
          <div className="bg-blue-50/50 border border-blue-100 p-5 rounded-3xl">
            <h4 className="text-xs font-black text-blue-900 uppercase tracking-wider mb-3 flex items-center">
              <i className="fas fa-microscope text-blue-500 mr-2"></i>
              {isKrio ? "Recommended Clinic Lab Lab tests fɔ check:" : "Recommended Triage Laboratory Assays:"}
            </h4>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
              {briefResult.labDiagnosticTests.map((t, i) => (
                <li key={i} className="bg-white px-3 py-2 rounded-xl text-gray-700 font-bold border border-blue-200/50 shadow-sm flex items-center space-x-2">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                  <span>{t}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Global Research Data Guideline citations summary */}
          <div className="bg-gray-50 border border-gray-100 p-5 rounded-3xl">
            <span className="text-[9px] text-blue-600 font-black tracking-widest uppercase block mb-1">Global Medical Research Integration</span>
            <h4 className="font-bold text-gray-800 text-sm mb-2">{isKrio ? "Precise Medical Evidence & Research Guidelines:" : "Clinician Diagnostic Evidence Base:"}</h4>
            <p className="text-xs text-gray-600 leading-relaxed italic border-l-4 border-emerald-500 pl-3">
              {briefResult.researchGuidelineSummary}
            </p>
          </div>

          {/* Suggested Patient Inquiries / Questions */}
          <div>
            <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-3">
              {isKrio ? "Questions you should ask the Doctor/Nurse:" : "Suggested Questions for Doctor Engagement:"}
            </h4>
            <ul className="space-y-2 text-xs text-gray-600">
              {briefResult.suggestedDoctorQuestions.map((q, i) => (
                <li key={i} className="flex items-start">
                  <span className="bg-yellow-100 text-yellow-800 w-5 h-5 rounded-md flex items-center justify-center font-bold mr-3 shrink-0">{i+1}</span>
                  <span className="font-semibold mt-0.5">{q}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Action buttons (Save/Print) */}
          <div className="flex gap-3 pt-4 border-t border-gray-100">
            <button
              onClick={handleSaveToCasebook}
              className="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-2xl shadow hover:shadow-md transition active:scale-95 text-xs flex items-center justify-center space-x-2"
            >
              <i className="fas fa-bookmark"></i>
              <span>{isKrio ? "Sɛv Brief fɔ Offline View" : "Save Brief to My Case Book"}</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-4 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 font-extrabold rounded-2xl shadow transition active:scale-95 text-xs flex items-center justify-center space-x-2"
            >
              <i className="fas fa-print"></i>
              <span>{isKrio ? "Print/PDF" : "Print Brief"}</span>
            </button>
          </div>
        </div>
      )}

      {/* Embedded Printable Form Factor - Only visible when printed */}
      {briefResult && (
        <div className="print-only hidden print:block pt-8 border-t border-gray-300">
          <div className="text-center pb-6 mb-6 border-b border-gray-200">
            <h2 className="text-2xl font-black text-gray-800 tracking-wide uppercase">DoxaCare AI Clinical Assessment Brief</h2>
            <p className="text-xs text-blue-600 uppercase font-black">Prepared for Clinician Review in Sierra Leone</p>
            <p className="text-[10px] text-gray-400 uppercase mt-1">Generated: {new Date().toLocaleDateString()}</p>
          </div>

          <div className="space-y-6">
            <div className="bg-gray-100 p-4 rounded-xl border border-gray-300">
              <h4 className="text-xs font-bold uppercase text-gray-500 mb-2">Patient Intake Characteristics</h4>
              <p className="text-sm"><strong>Original Concern:</strong> {topic}</p>
              <p className="text-sm"><strong>Symptom Timeline:</strong> {timeline}</p>
              <p className="text-sm"><strong>Obstetric Preg Status:</strong> {isPregnant ? 'YES (PREGNANT/OBSTETRIC WATCH)' : 'NO'}</p>
              <p className="text-sm"><strong>Reported Urgent Signs:</strong> {selectedSevere.map(s => severeOptions.find(o => o.value === s)?.label).join(', ') || 'None'}</p>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase text-gray-500 mb-2">Triage & Risk Stratification</h4>
              <p className="text-lg font-black text-red-700">{briefResult.clinicalTriage} SEVERITY LEVEL</p>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase text-gray-500 mb-2">Suggested Laboratory Diagnostics (Sierra Leone standard)</h4>
              <ul className="list-disc pl-5 text-sm space-y-1">
                {briefResult.labDiagnosticTests.map((t, i) => (
                  <li key={i}>{t}</li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase text-gray-500 mb-2">Research Baseline & Clinical Justification (WHO / NPHA Guidelines)</h4>
              <p className="text-sm text-gray-700 italic leading-relaxed">
                {briefResult.researchGuidelineSummary}
              </p>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase text-gray-500 mb-2">Suggested Consultation Inquiries</h4>
              <ul className="list-decimal pl-5 text-sm space-y-1">
                {briefResult.suggestedDoctorQuestions.map((q, i) => (
                  <li key={i}>{q}</li>
                ))}
              </ul>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-300 text-center text-[10px] text-gray-400">
              <p>Disclaimer: This clinical assessment was prepared by DoxaCare AI utilizing advanced global health guidelines and recent epidemiological frameworks. This report is for bridging support and does not replace active in-person examination or professional laboratory diagnostics.</p>
            </div>
          </div>
        </div>
      )}

      {/* Floating alert toast */}
      {toastMessage && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-gray-900 border border-gray-800 text-white text-xs px-5 py-3 rounded-2xl shadow-xl flex items-center space-x-2 animate-bounce z-50">
          <i className="fas fa-check-circle text-green-500"></i>
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
};

export default ClinicalBriefCard;
